# RFC evidence continuation, 2026-10-05

## Ownership

Actual omp session/native identity: 01a0fdb1-2ee3-7297-adf9-cd21f70400f0. Prefix native commands with `CGO_ENABLED=0 CLAUDE_CODE_SESSION_ID=01a0fdb1-2ee3-7297-adf9-cd21f70400f0`. The historical ba93202e identity now resolves to the enum spec; do not reclaim or release that session's state. Current native claim is the existing in-progress parent `spec-rfc-verdict-test-fix-pass.md`. This is the same continued checkout session that pulled before its original work; do not pull under shared edits.

Owner explicitly says the other session owns verification repairs, RFC tooling, site, UI fixtures, command dispatch, their verification, and test-health regeneration. This pass does not edit those surfaces or run their full suites. Scoped native unit recording was verified at observationRunner: anchored selected unit/package, clean run and coverage, Go overlay, then attributed red. No production files are mutated by these recordings.

## Files changed and acceptance covered

- `rfc/discrimination/rfc7432.json`, `rfc/audit/rfc7432.json`: eight missing scoped records and independent first stamp of RFC7432-8.2.1-2. Landed as `48110793c1`, together with the EVPN continuation in `plan/handover/rfc-verdict-test-fix-pass/RULINGS.md` and native verification debt.
- Four MRT carriers gained eight bounded tags: reactor/mrt_migration_epoch_test.go, reactor/mrt_collision_epoch_test.go, analyze/mrt_boundary_test.go, mrt/session_context_boundaries_test.go. Native approvals preceded all edits. Four RFC-prefixed renames are planned in scratch/step4-mrt-rename.plan and must run after the evidence commit makes sources HEAD-clean.
- `internal/mrt/rfc8050_session_context_test.go`: corrected one overstated positive claim to exact decoded prefixes/IDs and ordinary-family ID absence. No assertion changed. Both existing native observations were renewed after approval.
- `rfc/discrimination/rfc8050.json`: eight new records plus corrected claim renewal. `rfc/audit/rfc8050.json`: two independent native rejudgments retain weak. `RULINGS.md`: current proof evidence and limits; historical suggestion that enrollment alone closes MRT corrected.
- RFC7313 two helper-dependent positives were re-observed; canonical record bytes remain unchanged. Eight collateral forwarding tuples already renewed and reused; disposition is in scratch/step4-gr-forward-disposition.json.

## Observed verification

All four scoped native recording jobs exited 0. Each record requires a clean run and observed producer-disabled failure. These are 20 observations, not 20 semantic mutants:
- EVPN 8: scratch/job-rfc-step4-evpn-d6d3196f.log.
- MRT 8: scratch/job-rfc-step4-mrt-aac0f32b.log.
- Refresh 2: scratch/job-rfc-step4-gr-cf6e5d61.log.
- Corrected MRT claim 2: scratch/job-rfc-step4-mrt-claim-b5e3b917.log.

Native attribution validates full output before retaining an excerpt; long panic excerpts can omit leading RUN/halt lines. Parent read requireCleanGreen, requireRed, judgeRed and killedByTheBreak. Do not rerun successful observations merely because the retained excerpt is shorter.

Independent reviewers MRTSubtypeRejudge and MRTContextRejudge accepted the new bounded tags. The latter also accepted the corrected existing claim. Their native-ready notes were stamped with mode rejudge. No production or executable assertion changes occurred.

## Do not assume

MRT x-1 still lacks a live isolated-family case discriminating receive/send context substitution. MRT x-4 lacks the complete exact no-OPEN decoding matrix. Both remain weak. LLGR weak rows and four-workflow acceptance are unchanged. No absent-feature development or parent/child closure is authorized by these records. Remaining BGP weak groups are in the earlier local inventory report, not silently resolved.

Pending at this write: execute prepared MRT evidence commit, native rename all four now-tagged clean carriers, commit pure rename, regenerate derived index, run final RFC gate and tracked compile gate once. Full worktree verification remains with the other session and no push is authorized. Commit namespace 22323411; approvals in tmp/commit-rfc-approved-22323411.md. Always use the exact message/script paths printed by native commit create.

## Final evidence batch result

The pending operations above completed. MRT enrollment and independent rejudgments landed as `14698ed9c4`. The native four-file rename and lifecycle citations landed as `d4e3375ddf`; every carrier rename was 100% byte-identical. Native rename migrated the audit and discrimination keys, and `rfc index-update` regenerated the derived RFC indexes.

- Final `rfc check`: exit 0, `rfc-requirements OK`; 8,186 tags resolved, zero discrimination records owed. Full output: scratch/job-rfc-step4-final-rfc-a7878a02.log. These corpus gate counts are not claims that all requirements are proven.
- Final `repo compiles check`: exit 0 at committed `d4e3375ddfb2`. All five registered flavors passed: distro (865 packages), appliance (865), setup (864), host (864), installer (866). The command excludes test execution.
- Final `doc check verify`: exit 1, three published-catalog drift findings only: ../wiki/command-catalog.md, ../gh-pages/reference/cli/index.md and ../gh-pages/llms.txt. The two site findings name the stale retain-routes description. Source references passed: 2,938 paths and 647 packages; all 3,025 digest anchors resolved. Full output: scratch/job-rfc-step4-final-doc-dd6c4454.log.
- That catalog drift is already recorded in plan/journal/stale-artifact-reused.md, dated 2026-10-04. No duplicate journal row or competing site fix was made; the owner's other session owns these publishing repairs.
- The doc gate also warned that its derived discovery index was stale. `doc index write` then succeeded, regenerating ai/DOCS-TO-CODE.md (327 design docs) and ai/CODE-TO-DOCS.md (2,938 code paths, 647 packages). The full doc gate was not rerun to reconfirm its known catalog red.

This evidence batch is committed and its scoped verification is recorded. The parent and BGP child remain open with the proof limits above. Full worktree verification and test-health regeneration remain with the other session; native verification debt is not represented as cleared. No push ran.
