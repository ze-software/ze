// Design: docs/architecture/update-building.md -- generic plugin UPDATE builders
// Overview: update_build.go -- core UpdateBuilder struct and unicast builders

package message

import (
	"net/netip"

	"github.com/ze-software/ze/internal/core/bgp/attribute"
	bgpctx "github.com/ze-software/ze/internal/core/bgp/context"
)

// PluginParams contains parameters for building a generic plugin route UPDATE.
//
// The plugin's config parser pre-builds the family-specific NLRI and any
// family-specific path attributes (ext-communities, prefix-sid, NEXT_HOP code-3,
// communities, MED, originator-id, cluster-list, ...) as RawAttrs wire bytes.
// BuildPlugin owns only the session-context attributes: ORIGIN (default IGP
// unless the plugin supplied code 1), AS_PATH (ASN4-encoded from ASPath),
// LOCAL_PREF (iBGP-gated), and MP_REACH_NLRI.
type PluginParams struct {
	AFI      uint16
	SAFI     byte
	IsIPv6   bool
	NLRI     []byte // One or more concatenated NLRIs for this family/SAFI.
	NextHop  netip.Addr
	RawAttrs [][]byte // Pre-built extra attribute wire bytes (flags+code+len+value).

	// ASPath is the configured AS_PATH (nil = local-origin default).
	ASPath []uint32
	// LocalPreference is the configured LOCAL_PREF value (0 = default 100 on iBGP).
	LocalPreference uint32
	// MapV4NextHop maps an IPv4 next-hop to IPv4-mapped IPv6 in MP_REACH for IPv6
	// families (MUP / SR-Policy). MVPN/VPLS/FlowSpec leave it false.
	MapV4NextHop bool
}

// pluginMaxAttrs bounds the per-route attribute count: AS_PATH + AS4_PATH +
// ORIGIN + LOCAL_PREF + MP_REACH + up to pluginMaxRawAttrs plugin-supplied
// attributes. An append past the bound still works; it allocates.
const (
	pluginMaxRawAttrs = 16
	pluginMaxAttrs    = pluginMaxRawAttrs + 5
)

// BuildPlugin builds an UPDATE message for a plugin-registered route.
// Multiprotocol routes carry next-hop in MP_REACH_NLRI; a family that also needs
// a legacy NEXT_HOP (code 3) attribute (IPv4 MUP/MVPN) supplies it via RawAttrs.
//
// Wire order is fixed by OrderAttributes (MP_UNREACH first, regular attrs by
// code, MP_REACH included), so the order attributes are added here is irrelevant.
func (ub *UpdateBuilder) BuildPlugin(p PluginParams) *Update {
	ub.resetScratch()

	var attrBuf [pluginMaxAttrs]attribute.Attribute
	var rawBuf [pluginMaxRawAttrs]fullRawAttribute

	// AS_PATH (code 2) is always built here: the plugin cannot encode it without
	// the negotiated ASN4 capability. The plugin must never supply code 2.
	// appendASPath adds the RFC 6793 Section 4.2.2 AS4_PATH when the peer is an
	// OLD speaker and the path holds a non-mappable AS number.
	attrs := ub.appendASPath(attrBuf[:0], p.ASPath)

	// Plugin-supplied raw attributes. Track ORIGIN and drop any AS_PATH/LOCAL_PREF
	// (those are owned by BuildPlugin / session context).
	pluginOrigin := false
	rb := 0
	for _, raw := range p.RawAttrs {
		if len(raw) < 3 || rb >= len(rawBuf) {
			continue
		}
		//exhaustive:ignore // Only session-owned attributes need special handling; other plugin bytes pass through.
		switch attribute.AttributeCode(raw[1]) {
		case attribute.AttrASPath, attribute.AttrLocalPref:
			continue
		case attribute.AttrOrigin:
			pluginOrigin = true
		}
		rawBuf[rb] = fullRawAttribute{data: raw}
		attrs = append(attrs, &rawBuf[rb])
		rb++
	}

	// ORIGIN (code 1): default IGP unless the plugin supplied its own.
	if !pluginOrigin {
		attrs = append(attrs, attribute.OriginIGP)
	}

	// LOCAL_PREF (code 5): well-known discretionary, iBGP only (RFC 4271 Section 5.1.5).
	if ub.IsIBGP {
		lp := p.LocalPreference
		if lp == 0 {
			lp = 100
		}
		attrs = append(attrs, attribute.LocalPref(lp))
	}

	attrs = append(attrs, ub.buildMPReachPlugin(p))

	return &Update{
		PathAttributes: ub.packAttributesOrderedInto(attrs, nil),
	}
}

// buildMPReachPlugin constructs MP_REACH_NLRI for a plugin route.
func (ub *UpdateBuilder) buildMPReachPlugin(p PluginParams) *rawAttribute {
	panic("BUG: ./le rfc discriminate-record disabled this producer to observe the red")
}

// fullRawAttribute wraps a pre-built attribute wire (flags+code+len+value),
// exposing Flags/Code/Len/WriteTo for the value portion so WriteAttrTo
// can write its own header.
type fullRawAttribute struct {
	data []byte // complete wire: flags(1)+code(1)+len(1or2)+value
}

func (r *fullRawAttribute) Code() attribute.AttributeCode {
	if len(r.data) >= 2 {
		return attribute.AttributeCode(r.data[1])
	}
	return 0
}

func (r *fullRawAttribute) Flags() attribute.AttributeFlags {
	if len(r.data) >= 1 {
		return attribute.AttributeFlags(r.data[0])
	}
	return 0
}

func (r *fullRawAttribute) valueOffset() int {
	if len(r.data) >= 1 && (r.data[0]&0x10) != 0 {
		return 4 // extended length: flags(1)+code(1)+len(2)
	}
	return 3 // normal: flags(1)+code(1)+len(1)
}

func (r *fullRawAttribute) Len() int {
	off := r.valueOffset()
	if len(r.data) <= off {
		return 0
	}
	return len(r.data) - off
}

func (r *fullRawAttribute) WriteTo(buf []byte, off int) int {
	voff := r.valueOffset()
	if len(r.data) <= voff {
		return 0
	}
	return copy(buf[off:], r.data[voff:])
}

func (r *fullRawAttribute) WriteToWithContext(buf []byte, off int, _, _ *bgpctx.EncodingContext) int {
	return r.WriteTo(buf, off)
}
