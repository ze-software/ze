package reactor

import (
	"testing"

	"github.com/stretchr/testify/require"
)

// A fixture retaining a received UPDATE must retire it after its workers stop.
// Stopping the cache's scan alone leaves adopted pool slots outstanding, so a
// repeated package run can exhaust buffers needed by unrelated announce tests.
func TestFanoutFixtureReturnsAdoptedBuffers(t *testing.T) {
	_, before := bufMuxStd.Stats()
	t.Run("withdrawal", func(t *testing.T) {
		h := newFanoutHarnessWith(t, 2, 1, fanoutOpts{groups: true, withdraw: true})
		require.NoError(t, h.forward())
		for _, sent := range h.delivered(t, 2) {
			require.Len(t, sent.body, 12)
			require.Equal(t, []byte{24, 10, 0, 0, 24, 10, 0, 1}, sent.body[2:len(sent.body)-2],
				"the fixture must actually exercise a pooled withdrawal")
		}
	})
	_, after := bufMuxStd.Stats()
	require.Equal(t, before, after, "fixture cleanup must return every adopted read buffer after the workers finish")
}
