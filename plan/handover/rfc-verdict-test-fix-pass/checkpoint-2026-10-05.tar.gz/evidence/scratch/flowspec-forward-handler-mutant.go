// Design: docs/architecture/core-design.md -- generic attribute modification handlers
// RFC: rfc/short/rfc4271.md -- path attribute flags and the Extended Length header class (Section 4.3)
// RFC: rfc/short/rfc4456.md -- ORIGINATOR_ID set-if-absent and CLUSTER_LIST prepend (Section 8)
// RFC: rfc/short/rfc4760.md -- MP_REACH_NLRI value layout (Section 3)
// RFC: rfc/short/rfc7606.md -- the attribute-discard action a marker records (Section 7.7)
// RFC: rfc/drafts/draft-mangin-idr-attr-tombstone-00.txt -- ATTR_TOMBSTONE flags (Section 4.2) and the rebuild marker (Section 5.1)
// Related: filter_delta.go -- textDeltaToModOps produces the AttrModSet and AttrModSuppress ops these handlers consume
// Related: forward_build.go -- buildModifiedPayload dispatches to registered handlers

package reactor

import (
	"github.com/ze-software/ze/internal/component/bgp/filterapi"
	"github.com/ze-software/ze/internal/core/bgp/attribute"
	"github.com/ze-software/ze/internal/core/family"
)

// lastSetOrSuppress is the package-local spelling of filterapi.LastSetOrSuppress.
//
// The fold moved to filterapi so the community and OTC handlers, which live in
// plugin packages and cannot see this one, apply the SAME rule instead of each
// re-deriving it. Two of the three re-derivations had already lost the Suppress
// case (see the filterapi doc comment).
func lastSetOrSuppress(ops []filterapi.AttrOp) (idx int, suppress bool) {
	return filterapi.LastSetOrSuppress(ops)
}

// keepOrDrop finishes a plan that has no modification to make: the source
// attribute is emitted unchanged when it exists, and nothing is emitted when it
// does not.
//
// KeepAll rather than a rebuilt copy, because rebuilding decides the header size
// class afresh and would normalize a legal-but-unusual source header, moving a
// byte on the wire for a route nobody asked to change. It is also the cheapest
// outcome: a verbatim slot coalesces into the surrounding copy run.
func keepOrDrop(p *filterapi.AttrPlan) {
	if p.Source() == nil {
		p.Drop()
		return
	}
	p.KeepAll()
}

// genericAttrSetHandler returns an AttrModHandler that supports AttrModSet for any
// attribute code. On Set it emits the operation's value bytes under a fresh header;
// on Suppress it drops the attribute; with neither it keeps the source unchanged.
//
// This enables the policy filter text-delta-to-wire bridge for attributes that don't
// have specialized handlers (community types and OTC have their own).
func genericAttrSetHandler(flags, code byte) filterapi.AttrModHandler {
	return func(p *filterapi.AttrPlan) {
		setIdx, suppress := lastSetOrSuppress(p.Ops())

		// Suppress: emit nothing, removing the attribute.
		if setIdx >= 0 && suppress {
			p.Drop()
			return
		}
		if setIdx < 0 {
			keepOrDrop(p)
			return
		}

		// The operation's bytes are named, not copied: they already exist in the
		// accumulator and stay valid for the whole rebuild.
		p.Op(setIdx)
		p.Emit(flags, code)
	}
}

// Attribute flags per RFC 4271 Section 4.3:
//   - 0x40 = Well-known, Transitive (ORIGIN, AS_PATH, NEXT_HOP, LOCAL_PREF, ATOMIC_AGGREGATE)
//   - 0x80 = Optional, Non-transitive (MED)
//   - 0xC0 = Optional, Transitive (AGGREGATOR, ORIGINATOR_ID, CLUSTER_LIST)

// genericAttrCodes lists attribute codes that need generic set handlers.
// Community types (8, 16, 32) and OTC (35) already have specialized handlers
// registered by their plugins.
var genericAttrCodes = []struct {
	code  attribute.AttributeCode
	flags byte
}{
	{attribute.AttrOrigin, 0x40},          // Well-known mandatory
	{attribute.AttrASPath, 0x40},          // Well-known mandatory
	{attribute.AttrAS4Path, 0xC0},         // Optional transitive (RFC 6793)
	{attribute.AttrNextHop, 0x40},         // Well-known mandatory
	{attribute.AttrMED, 0x80},             // Optional non-transitive
	{attribute.AttrLocalPref, 0x40},       // Well-known (IBGP)
	{attribute.AttrAtomicAggregate, 0x40}, // Well-known discretionary
	{attribute.AttrAggregator, 0xC0},      // Optional transitive
	{attribute.AttrAS4Aggregator, 0xC0},   // Optional transitive (RFC 6793 Section 3)
	{attribute.AttrOriginatorID, 0x80},    // Optional non-transitive (RFC 4456)
	{attribute.AttrClusterList, 0x80},     // Optional non-transitive (RFC 4456)
	{attribute.AttrAIGP, 0x80},            // Optional NON-transitive (RFC 7311 Section 3)
	{attribute.AttrPrefixSID, 0xC0},       // Optional transitive (RFC 8669)
}

// originatorIDHandler handles ORIGINATOR_ID (type 9, RFC 4456 Section 8).
// AttrModSet: set only if the attribute is absent in the source. If already present,
// the existing value is kept unchanged (the original originator is preserved).
func originatorIDHandler() filterapi.AttrModHandler {
	return func(p *filterapi.AttrPlan) {
		// One fold, read by both branches below: this runs once per destination
		// per route, so the scan is not repeated.
		_, suppress := filterapi.LastSetOrSuppress(p.Ops())

		// RFC 4456 Section 8: "the ORIGINATOR_ID SHOULD NOT be changed" by a
		// reflector that finds one already present.
		//
		// A Suppress operation is REFUSED here rather than honored, for the same
		// reason as OTC (plugins/role/otc.go): RFC4456-8-4 is a gated MUST, the
		// ORIGINATOR_ID value "MUST be preserved unchanged through the
		// reflection chain", and removing the attribute is a change.
		//
		// But it is refused OUT LOUD. Reading Set alone discarded the operation
		// in silence, which is precisely how the community handler shipped a
		// live fail-open: consumed, ignored, re-emitted, nothing said
		// (ai/rules/evidence.md). No producer suppresses code 9 today.
		if p.Source() != nil {
			if suppress {
				fwdLogger().Warn("ORIGINATOR_ID suppression refused: RFC 4456 Section 8 requires the value to be preserved unchanged through the reflection chain",
					"attribute-code", int(attribute.AttrOriginatorID))
			}
			p.KeepAll()
			return
		}
		// Absent source: a Suppress means the attribute must not be created. The
		// preservation clause above does not reach here, because there is
		// nothing yet to preserve.
		if suppress {
			p.Drop()
			return
		}
		for i, op := range p.Ops() {
			if op.Action != filterapi.AttrModSet || len(op.Buf) != 4 {
				continue
			}
			p.Op(i)
			// Flags: 0x80 = Optional, Non-transitive (RFC 4456).
			p.Emit(0x80, byte(attribute.AttrOriginatorID))
			return
		}
		p.Drop()
	}
}

// clusterListHandler handles CLUSTER_LIST (type 10, RFC 4456 Section 8).
// AttrModPrepend: prepends a 4-byte cluster-id before any existing cluster-list values.
// AttrModSet: replaces the entire cluster-list.
//
// The prepend path is a fragment list: the new cluster-ids come from their
// operation buffers and the existing list is named where it already sits, so a
// long cluster list is never copied into an intermediate.
func clusterListHandler() filterapi.AttrModHandler {
	code := byte(attribute.AttrClusterList)
	return func(p *filterapi.AttrPlan) {
		ops := p.Ops()
		setIdx := -1
		prepends := 0
		for i := range ops {
			switch {
			case ops[i].Action == filterapi.AttrModSet:
				setIdx = i
			case ops[i].Action == filterapi.AttrModPrepend && len(ops[i].Buf) == 4:
				prepends++
			}
		}

		// Suppress removes the attribute outright, and it beats a prepend the
		// same way it does in aspathHandler below: the last Set-or-Suppress
		// decides whether the attribute exists at all, and a prepend only shapes
		// one that does. Without this branch a lone Suppress left setIdx at -1
		// and prepends at 0, so keepOrDrop re-emitted the source CLUSTER_LIST
		// and the operation was discarded in silence -- the same fail-open the
		// community handler shipped for `session { community { send ... } }`.
		// CLUSTER_LIST is Optional Non-transitive, so removing it is legal and
		// no RFC 4456 preservation clause applies to the LIST itself.
		if sIdx, suppress := filterapi.LastSetOrSuppress(ops); sIdx >= 0 && suppress {
			p.Drop()
			return
		}

		// Set overrides everything.
		if setIdx >= 0 {
			p.Op(setIdx)
			p.Emit(0x80, code) // Optional, Non-transitive
			return
		}
		if prepends == 0 {
			keepOrDrop(p)
			return
		}

		for i := range ops {
			if ops[i].Action == filterapi.AttrModPrepend && len(ops[i].Buf) == 4 {
				p.Op(i)
			}
		}
		if val := p.Value(); len(val) > 0 {
			p.Keep(0, len(val))
		}
		p.Emit(0x80, code)
	}
}

// mpReachNextHopHandler handles next-hop rewriting inside MP_REACH_NLRI
// (type 14, RFC 4760 Section 3).
//
// The op Buf carries the new next-hop bytes (16 bytes for an IPv6 global
// address, or 32 bytes for a global + link-local pair per RFC 2545). This is the
// handler the fragment model was generalized from: the AFI/SAFI header and the
// whole NLRI tail are NAMED where they already sit, one synthesized byte carries
// the new next-hop length, and the next-hop itself comes from its operation
// buffer. The NLRI tail is therefore copied exactly once, straight into the
// output, however many prefixes the route carries.
//
// If the source attribute is absent or its value is too short to parse, the
// handler emits nothing: MP_REACH_NLRI carries the route's NLRI itself, so the
// rewrite only makes sense when a source attribute already exists.
//
// Only AttrModSet ops are honored (last-wins). AttrModSuppress on a
// MP_REACH_NLRI would strip the entire route, which is a withdraw -- that is
// expressed via ModAccumulator.SetWithdraw(), not via this handler.
// A Set with an empty buffer is a real rewrite for a family without next hops,
// not an absent operation. Such a family cannot acquire a next hop from any Set.
func mpReachNextHopHandler() filterapi.AttrModHandler {
	return func(p *filterapi.AttrPlan) {
		val := p.Value()
		noNextHop := false
		if len(val) >= 3 {
			fam := family.Family{AFI: family.AFI(uint16(val[0])<<8 | uint16(val[1])), SAFI: family.SAFI(val[2])}
			noNextHop = !fam.NeedsNextHop()
		}
		// Pick the last Set op.
		setIdx := -1
		ops := p.Ops()
		for i := range ops {
			if ops[i].Action == filterapi.AttrModSet && (len(ops[i].Buf) > 0 || noNextHop) {
				setIdx = i
			}
		}

		// No rewrite requested: keep the source unchanged.
		if setIdx < 0 {
			keepOrDrop(p)
			return
		}

		// Cannot construct MP_REACH_NLRI from nothing -- the NLRI portion lives
		// in the source attribute value.
		src := p.Source()
		if src == nil {
			p.Drop()
			return
		}

		// Value layout: AFI(2) + SAFI(1) + NHLen(1) + NH(NHLen) + Reserved(1) + NLRI.
		if len(val) < 5 {
			p.Drop()
			return
		}
		nhLen := int(val[3])
		nhEnd := 4 + nhLen
		if nhEnd+1 > len(val) { // +1 for the reserved byte
			p.Drop()
			return
		}

		// The new next-hop must be exactly one of the allowed lengths:
		//   - 4  bytes: IPv4 next-hop (used by labeled unicast / VPN families).
		//   - 16 bytes: IPv6 global-only next-hop.
		//   - 24 bytes: RD + IPv6 global (RFC 4659 Section 3.2.1.1), the
		//     VPN-IPv6 form egressNextHopGlobalHalf cuts from the 48-octet pair.
		//   - 32 bytes: IPv6 global + link-local per RFC 2545 Section 3.
		// A mismatched op length is a caller bug; the route is left unchanged
		// (the caller should have produced a valid op).
		newNHLen := len(ops[setIdx].Buf)
		if noNextHop {
			if nhLen >= 0 { // MUTATION: retain every received FlowSpec next hop.
				p.KeepAll()
				return
			}
			newNHLen = 0
		} else if newNHLen != 4 && newNHLen != 16 && newNHLen != 24 && newNHLen != 32 {
			p.KeepAll()
			return
		}

		p.Keep(0, 3)              // AFI + SAFI, already on the wire
		p.NewByte(byte(newNHLen)) // the one byte that exists nowhere else
		if newNHLen != 0 {
			p.Op(setIdx) // the new next-hop
		}
		p.Keep(nhEnd, len(val)-nhEnd)

		// The source flags carry the attribute's optional/transitive bits; Emit
		// decides the Extended Length bit from the FINAL value length, which is
		// what a next-hop that grows or shrinks across the 255-octet boundary
		// needs (RFC 4271 Section 4.3).
		p.Emit(src[0], byte(attribute.AttrMPReachNLRI))
	}
}

// aspathHandler handles AS_PATH (type 2) with support for AttrModPrepend.
// Prepend inserts a new AS_SEQUENCE segment before the existing AS_PATH value.
// Set replaces the entire attribute (via genericAttrSetHandler fallback).
func aspathHandler() filterapi.AttrModHandler {
	setHandler := genericAttrSetHandler(0x40, byte(attribute.AttrASPath))

	return func(p *filterapi.AttrPlan) {
		ops := p.Ops()
		hasPrepend := false
		for i := range ops {
			if ops[i].Action == filterapi.AttrModPrepend && len(ops[i].Buf) > 0 {
				hasPrepend = true
				break
			}
		}
		if !hasPrepend {
			// No prepend: delegate to the generic set handler.
			setHandler(p)
			return
		}

		setIdx, suppress := lastSetOrSuppress(ops)
		if setIdx >= 0 && suppress {
			p.Drop()
			return
		}

		// Prepend: the new segments first, then the base path. The base is the
		// Set value when one is present, otherwise the source value where it
		// already sits.
		for i := range ops {
			if ops[i].Action == filterapi.AttrModPrepend && len(ops[i].Buf) > 0 {
				p.Op(i)
			}
		}
		if setIdx >= 0 {
			p.Op(setIdx)
		} else if val := p.Value(); len(val) > 0 {
			p.Keep(0, len(val))
		}
		p.Emit(0x40, byte(attribute.AttrASPath)) // Well-known, Transitive
	}
}

// tombstoneHandler handles ATTR_TOMBSTONE (type 252,
// draft-mangin-idr-attr-tombstone-00), the marker a rebuild writes in place of
// an attribute it discarded. `wireu.ASPathEdit` records one for an AGGREGATOR
// whose length RFC 7606 Section 7.7 makes unreadable, and without a handler here
// the rebuild would suppress the whole route rather than emit the marker
// (planAttr, forward_build.go).
//
// It is not a generic set handler, because the flags of every other attribute
// follow its own type code and this one's do not: Section 4.2 derives the
// Transitive bit from the DISCARDED attributes. The value carries their codes,
// one (code, reason) pair each (Section 4.3), so tombstoneFlags reads them.
//
// A marker the SOURCE already carries is kept and the local pairs are dropped.
// Section 5.1 asks for the two to be merged into one marker, which no rail in Ze
// builds today; replacing the upstream marker would delete an upstream speaker's
// diagnostic from the wire, and that is the outcome worth refusing. The RFC 7606
// discard itself still lands, because it is a separate operation on the
// discarded attribute's own code.
func tombstoneHandler() filterapi.AttrModHandler {
	return func(p *filterapi.AttrPlan) {
		setIdx, suppress := lastSetOrSuppress(p.Ops())

		if setIdx >= 0 && suppress {
			p.Drop()
			return
		}
		if setIdx < 0 {
			keepOrDrop(p)
			return
		}
		if p.Source() != nil {
			fwdLogger().Warn("ATTR_TOMBSTONE already present, forwarding the upstream marker and dropping the local pairs",
				"upstreamValueLen", len(p.Value()), "localValueLen", len(p.Ops()[setIdx].Buf))
			p.KeepAll()
			return
		}

		p.Op(setIdx)
		p.Emit(tombstoneFlags(p.Ops()[setIdx].Buf), byte(attribute.AttrTombstone))
	}
}

// tombstoneFlags derives an ATTR_TOMBSTONE's flags from the attribute codes its
// value records.
//
// draft-mangin-idr-attr-tombstone-00 Section 4.2 fixes the Optional bit at 1 and
// derives the Transitive bit from the discarded attributes, and Section 5.7
// resolves a marker that names several: transitive only when every discarded
// attribute was transitive, and the conservative 0x80 otherwise. A code this
// speaker cannot place takes the same conservative answer, so an unknown code
// yields a marker that is ignored downstream rather than one propagated under a
// transitivity nobody established.
//
// The per-code flags come from genericAttrCodes, which is where this file already
// declares them, so the two cannot disagree (ai/rules/principles.md). The
// Extended Length bit is not set here: AttrPlan.Emit derives it from the final
// value length, which is what Section 4.2 asks of a marker written by rebuild.
//
// A marker whose value is produced by a GENERATOR reads as empty here, because
// those bytes exist only at write time, and it takes the conservative answer for
// the same reason an unknown code does. Every producer today records the pair as
// bytes (wireu.ASPathEdit.recordAggregatorDiscard), which is what a two-octet value
// costs nothing to do.
func tombstoneFlags(value []byte) byte {
	if len(value) < 2 {
		return byte(attribute.FlagOptional)
	}
	for off := 0; off+1 < len(value); off += 2 {
		declared, known := canonicalAttrFlags(value[off])
		if !known || declared&byte(attribute.FlagTransitive) == 0 {
			return byte(attribute.FlagOptional)
		}
	}
	return byte(attribute.FlagOptional | attribute.FlagTransitive)
}

// canonicalAttrFlags returns the flags genericAttrCodes declares for a type code,
// and whether that table names the code at all.
func canonicalAttrFlags(code byte) (flags byte, known bool) {
	for i := range genericAttrCodes {
		if byte(genericAttrCodes[i].code) == code {
			return genericAttrCodes[i].flags, true
		}
	}
	return 0, false
}

// attrModHandlersWithDefaults returns the registered AttrModHandler map with
// generic set handlers filled in for attribute codes that lack specialized handlers.
// Called by the reactor at startup instead of filterapi.AttrModHandlers() directly.
func attrModHandlersWithDefaults() map[uint8]filterapi.AttrModHandler {
	handlers := filterapi.AttrModHandlers()
	for _, entry := range genericAttrCodes {
		code := byte(entry.code)
		if handlers[code] == nil {
			handlers[code] = genericAttrSetHandler(entry.flags, code)
		}
	}
	// Override AS_PATH with handler supporting prepend (policy as-path-prepend).
	handlers[byte(attribute.AttrASPath)] = aspathHandler()
	// Override ORIGINATOR_ID and CLUSTER_LIST with specialized handlers
	// that support set-if-absent and prepend semantics (RFC 4456).
	handlers[byte(attribute.AttrOriginatorID)] = originatorIDHandler()
	handlers[byte(attribute.AttrClusterList)] = clusterListHandler()
	// MP_REACH_NLRI next-hop rewriting (RFC 4760 §3, RFC 2545 §3).
	handlers[byte(attribute.AttrMPReachNLRI)] = mpReachNextHopHandler()
	// ATTR_TOMBSTONE, whose flags are derived from the attributes it records
	// rather than from its own code (draft-mangin-idr-attr-tombstone-00).
	handlers[byte(attribute.AttrTombstone)] = tombstoneHandler()
	// BGP Prefix-SID: a next-hop change removes the SRv6 Service TLVs and keeps
	// every other TLV (RFC 8669 Section 3, RFC 9252 Section 2).
	handlers[byte(attribute.AttrPrefixSID)] = prefixSIDNextHopHandler()
	return handlers
}
