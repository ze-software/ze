# RFC-tagged test changes the owner approved

| Test | Reason |
|------|--------|
| reactor.TestMRTMigrationEpochUsesActualLocalOPEN | D-15: enroll reviewed RFC8050 actual-local-OPEN migration proof |
| reactor.TestMRTWinningCollisionPreservesOPEN | D-15: strengthen RFC8050-x-1 with isolated-family received/sent announcements and withdrawals distinguishing directional base/ADD-PATH subtypes; retain original OPEN and mixed-withdrawal assertions and add genuine ordinary-family negative coverage. |
| reactor.TestMRTCollisionWinnerReservation | D-15: strengthen shared live collision helper for RFC8050-x-1 directional subtype proof while preserving both published/taken reservation cases and all existing lifecycle assertions. |
| analyze.TestMRTEmptyMPFamilyRequiresContext | D-15: enroll reviewed RFC8050 empty MP context error and control proof |
| mrt_test.TestMRTContextCapabilityASNBoundaries | D-15: enroll reviewed RFC8050 capability ASN session identity proof |
| mrt_test.TestRFC8050SessionContextDecodesMixedDirections | D-15: correct the tagged claim to exact prefixes and Path Identifiers actually asserted; retain all assertions and renew both records |
| reactor.TestReflectedLinkLocalOnlyRouteIsWithheldFromAClientOffTheSegment | D-15: preserve the existing off-link case and same-segment control; add a negotiated directly attached client on a different connected segment so the reflection refusal is not masked by multihop withholding; assert exact withdrawal and no announcement for draft section 4 |
| reactor.TestAIGPForwardedMetricsReachFinalWire | D-15: correct the strip-only zero-cost expectation for RFC7311 section 3.4.3; preserve unchanged-next-hop, positive distance, saturation and recursive MissingAIGP controls; require explicit withdrawal when a requested local next hop lacks a nonzero increment |
| reactor.TestRFC7311DirectLinkCostNeverWrapsOrDisappears | D-15: correct the zero-cost strip-only expectation that encoded the RFC7311 section 3.4.3 defect; preserve exact positive source metric and saturation assertions, and prove withdrawal rather than an unqualified rewritten announcement |
| reactor.TestDefaultOriginateAppendsLinkLocalWhenSection3Holds | D-15 / P-1: standing approval for every tagged-unit edit this pass makes; supply the connected IPv6 topology explicitly while preserving every exact RFC2545 wire assertion. |
| reactor.TestSendAnnounceAppendsLinkLocalWhenSection3Holds | D-15 / P-1: standing approval for every tagged-unit edit this pass makes; supply the connected IPv6 topology explicitly while preserving every exact RFC2545 wire assertion. |
| reactor.TestForwardSplitSameContextKeepsRawSplit | D-15 / P-1: return the transcode buffer transferred to this fixture by buildFwdBody; preserve every wire assertion and RFC claim |
| reactor.TestFlowSpecRouteServerOmitsNextHop | D-15 / P-1: connect the fixture to the production shared event bus and actual TCP local address; preserve exact final-wire assertions and all families |
| gr.TestRFC4724ZeroRestartTimeExpiresAfterStaleMarking | D-15 / P-1: migrate the explicit DOWN retention handoff while preserving real RIB stale marking, immediate expiry, and no-resurrection assertions |
| mup.TestMUPST1IgnoresST2OnlyTLVs | D-15 / P-1: pass explicit announcement action through the unified NLRI decoder contract; preserve inputs, assertions and tags |
| mup.TestMUPST1DoesNotInterpretInapplicableAddressTLV | D-15 / P-1: pass explicit announcement action through the unified NLRI decoder contract; preserve inputs, assertions and tags |
| reactor.TestBGPLSPrefixCountCountsNLRIsNotPrefixBytes | Owner: "ok go". Approved implementation continuation; announcement-context false argument only, with all assertions and the RFC claim preserved. |
