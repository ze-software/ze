// Design: docs/architecture/rsvpte/mpls-rsvp-te.md -- RSVP-TE signaling engine
// RFC: rfc/short/rfc3209.md
// RFC: rfc/short/rfc2205.md
// Related: transport.go -- Transport seam the engine sends/receives over
// Related: build.go -- PATH/RESV/PathErr message construction
// Related: fsm.go -- LSP/LSPTable state this engine drives
// Related: admission.go -- bandwidth admission applied on reservation
//
// The engine ties the transport, codec, LSP state and admission control
// together. It implements the control plane for point-to-point LSPs:
//
//   - Ingress: sends PATH toward the tunnel endpoint, moves to ResvReceived/Up
//     when the matching RESV returns with a LABEL.
//   - Egress (SESSION.TunnelEndpoint is a local address): on PATH, runs
//     admission control, allocates a label and returns a RESV; on admission
//     failure returns a PathErr (RFC 2205 Section A.5).
//
// Transit nodes relay PATH/RESV state and program label swaps. PLRs retain the
// protected state during repair and refresh it through their bypass; merge
// points preserve the protected downstream identity.
package rsvpte

import (
	"bytes"
	"context"
	"errors"
	"log/slog"
	"net/netip"
	"sync"
	"sync/atomic"
	"time"
)

// fibProgrammer returns only after the native forwarding owner accepts or
// rejects a change. Signaling must not advertise a rejected installation.
type fibProgrammer interface {
	// programPush installs an ingress push entry: traffic to fec is forwarded
	// to nextHop with labels pushed, outermost first.
	programPush(fec netip.Prefix, labels []uint32, nextHop netip.Addr, tableID, pathMTU uint32) error
	// programSwap installs a transit swap entry: packets arriving with inLabel
	// are forwarded to nextHop with inLabel swapped for outLabel.
	programSwap(inLabel, outLabel uint32, nextHop netip.Addr, pathMTU uint32) error
	// programBackup installs a facility-backup local-repair entry (RFC 4090
	// Section 3.2): packets arriving with inLabel are forwarded to nextHop with
	// the outLabels stack imposed (the bypass label over the swapped protected
	// label). The kernel AF_MPLS swap already accepts a multi-label stack.
	programBackup(inLabel uint32, outLabels []uint32, nextHop netip.Addr, pathMTU uint32) error
	// programPop installs an egress pop entry: packets arriving with inLabel are
	// stripped of the label and forwarded toward nextHop (disposition).
	programPop(inLabel uint32, nextHop netip.Addr, pathMTU uint32) error
	// removePush withdraws a previously programmed push entry for fec.
	removePush(fec netip.Prefix, tableID uint32) error
	// removeSwap withdraws a previously programmed swap or pop entry for inLabel.
	removeSwap(inLabel uint32) error
}

var errForwardingUnavailable = errors.New("rsvp-te: native forwarding is unavailable")
var errReservationPolicy = errors.New("rsvp-te: reservation denied by local policy")

// engine runs the RSVP-TE control plane over a Transport. Per-LSP state is
// guarded by each LSP's own mutex (see LSP.mu), so the engine itself is
// stateless beyond its immutable dependencies.
type engine struct {
	transport Transport
	table     *lspTable
	admission *admissionController
	fib       fibProgrammer
	peers     peerIdentity
	control   sync.Mutex // Serializes received signaling with policy replacement.
	stopped   atomic.Bool
	// cfgPtr holds the active config behind an atomic pointer so OnConfigApply can
	// swap in a reloaded config (new interfaces, bypasses, refresh period) while the
	// run loop reads it. Read it via e.cfg(); never store the struct directly.
	cfgPtr atomic.Pointer[rsvpteConfig]
	log    *slog.Logger
}

// cfg returns the current engine config (atomically loaded; reload-safe). It
// copies the small struct (slice headers, not backing arrays), so snapshot it once
// per handler when reading several fields.
func (e *engine) cfg() rsvpteConfig { return *e.cfgPtr.Load() }

// setConfig swaps in a reloaded config (called from OnConfigApply) so the engine's
// runtime reads (selectBypass, admissionInterface, message builders) see it.
// RouterID is the LSR identity, fixed at engine creation (the engine is only built
// once a valid router-id exists); a changed/removed router-id is NOT adopted at
// runtime, since the engine's As4-based key and message-encode reads would then
// panic on the zero Addr. Changing the router-id is a restart-class operation.
func (e *engine) setConfig(cfg rsvpteConfig) {
	e.control.Lock()
	defer e.control.Unlock()
	cfg.RouterID = e.cfg().RouterID
	e.cfgPtr.Store(&cfg)
	e.refreshPeerIdentity()
	for _, lsp := range e.table.All() {
		if !cfg.Policy.allows(lsp.Key.SenderAddr, lsp.Key.TunnelEndpoint) {
			e.withdrawPolicy(lsp)
		}
	}
}

func newEngine(t Transport, table *lspTable, adm *admissionController, fib fibProgrammer, cfg rsvpteConfig, log *slog.Logger) *engine {
	e := &engine{transport: t, table: table, admission: adm, fib: fib, log: log}
	e.cfgPtr.Store(&cfg)
	if err := e.refreshLocalAddresses(); err != nil {
		e.log.Warn("rsvp-te: local address lookup failed", "error", err)
	}
	return e
}

// run consumes received packets until the context is canceled or the transport
// closes its channel.
func (e *engine) run(ctx context.Context) {
	recv := e.transport.Recv()
	for {
		select {
		case <-ctx.Done():
			return
		case pkt, ok := <-recv:
			if !ok {
				return
			}
			e.handlePacket(pkt)
		}
	}
}

func (e *engine) handlePacket(pkt Packet) {
	e.control.Lock()
	defer e.control.Unlock()
	if e.stopped.Load() {
		return
	}
	msg, err := DecodeMessage(pkt.Payload)
	if err != nil {
		e.log.Warn("rsvp-te: decode failed", "src", pkt.Src, "error", err)
		return
	}
	peer := pkt.Src
	if (msg.Header.MsgType == MsgTypePath || msg.Header.MsgType == MsgTypePathTear) && msg.HasHop {
		// PATH's IP source remains its original sender. The RSVP_HOP, not
		// that IP source, identifies the preceding signaling node.
		peer = msg.Hop.NextHop
		if pkt.Dst.IsValid() && (pkt.Dst != msg.Session.TunnelEndpoint || pkt.Src != msg.SenderTemplate.SenderAddr) {
			e.log.Warn("rsvp-te: PATH envelope does not match sender and session", "src", pkt.Src)
			return
		}
	}
	if msg.HasUnknownObject {
		e.rejectUnknownObject(peer, msg)
		return
	}
	switch msg.Header.MsgType {
	case MsgTypePath, MsgTypeResv, MsgTypeResvConf:
		if err := e.refreshLocalAddresses(); err != nil {
			e.log.Warn("rsvp-te: local address lookup failed", "error", err)
			return
		}
	}
	switch msg.Header.MsgType {
	case MsgTypePath:
		e.handlePath(peer, msg)
	case MsgTypeResv:
		e.handleResv(pkt.Src, msg)
	case MsgTypePathErr:
		e.handlePathErr(pkt.Src, msg)
	case MsgTypePathTear:
		e.handlePathTear(msg)
	case MsgTypeResvConf:
		e.handleResvConf(pkt, msg)
	case MsgTypeResvErr:
		e.handleResvErr(pkt.Src, msg)
	case MsgTypeResvTear:
		e.handleResvTear(pkt.Src, msg)
	default:
		e.log.Debug("rsvp-te: unhandled message type", "type", msg.Header.MsgType)
	}
}

// sendPath transmits an ingress, merged, or locally repaired PATH. A repaired
// PATH selects the exact bypass's mark-scoped MPLS forwarding context.
func (e *engine) sendPath(lsp *LSP) error {
	if e.stopped.Load() {
		return errForwardingUnavailable
	}
	if err := e.refreshLocalAddresses(); err != nil {
		return err
	}
	lsp.mu.Lock()
	original, originate := lsp.PSB, lsp.Role == RoleIngress && !lsp.ProtectionInUse
	bypassKey := lsp.Bypass
	lsp.mu.Unlock()
	if original == nil {
		return nil
	}
	if !e.cfg().Policy.allows(original.SenderTemplate.SenderAddr, original.Session.TunnelEndpoint) {
		return errReservationPolicy
	}
	var selected pathSelection
	if originate {
		var err error
		selected, err = e.resolveOriginatingPath(original)
		if err != nil {
			return err
		}
	}
	bypassMTU := e.bypassPathMTU(bypassKey)
	lsp.mu.Lock()
	if lsp.PSB != original {
		lsp.mu.Unlock()
		return errForwardingUnavailable
	}
	psb := original
	if originate {
		forward := *original
		forward.ERO = selected.ERO
		forward.Route = selected.Route
		service := psb.SenderTSpec.Service
		if service == 0 || service == serviceGeneral {
			service = serviceControlledLoad
		}
		if selected.Route.MTU == 0 {
			forward.Adspec = nil
		} else if original.Route.MTU != selected.Route.MTU || adspecPathMTU(original.Adspec, service) == 0 {
			advertisement := make([]byte, 48)
			n := encodeAdspec(advertisement, selected.Route.MTU, service)
			if n <= 0 {
				lsp.mu.Unlock()
				return errForwardingUnavailable
			}
			forward.Adspec = advertisement[:n]
		}
		original.Route, original.Adspec = forward.Route, forward.Adspec
		psb = &forward
		if !lsp.NextHop.IsValid() {
			lsp.NextHop = selected.Route.NextHop
		}
	}
	if lsp.Role == RoleIngress && !lsp.IsBypass && !lsp.ProtectionInUse && psb.Protection != nil {
		lsp.Bypass = nil
		if bk, ok := e.selectBypass(e.remainingERO(psb.ERO), psb.Protection); ok && e.repairSender(lsp.Key.SenderAddr).IsValid() {
			lsp.Bypass = &bk
		}
	}
	if len(lsp.MergedPaths) > 0 {
		merged := *psb
		merged.RefreshPeriod = e.cfg().RefreshPeriod
		psb = &merged
	}
	route := e.pathRoute(psb, lsp.NextHop)
	if originate {
		route.NextHop = selected.Route.NextHop
	}
	if lsp.ProtectionInUse && lsp.Bypass != nil {
		backup, err := backupPath(psb, lsp.Bypass.TunnelEndpoint, e.cfg().RouterID, lsp.RepairSender, e.cfg().RefreshPeriod, bypassMTU)
		if err != nil {
			lsp.mu.Unlock()
			return err
		}
		psb = backup
		lsp.RepairPathMTU = adspecPathMTU(backup.Adspec, backup.SenderTSpec.Service)
		route.Source = psb.SenderTemplate.SenderAddr
		route.NextHop = lsp.Bypass.TunnelEndpoint
		route.Lookup = route.NextHop
		route.IfIndex = 0
		route.TableID = bypassTableID(*lsp.Bypass)
	}
	raw := buildPath(psb, e.cfg().RouterID, defaultIPTTL)
	lsp.mu.Unlock()
	if len(raw) == 0 {
		return errForwardingUnavailable
	}
	if err := e.transport.SendPath(route, raw); err != nil {
		return err
	}
	if m := rsvpteMetricsPtr.Load(); m != nil {
		m.pathMsgSent.Inc()
	}
	return nil
}

// pathRoute keeps the IP session destination separate from the ERO's immediate
// forwarding hop. The transport must not infer routing from RSVP payloads.
func (e *engine) pathRoute(psb *pathStateBlock, nextHop netip.Addr) PathRoute {
	if !nextHop.IsValid() {
		nextHop = psb.Route.NextHop
		if !nextHop.IsValid() {
			nextHop = psb.Session.TunnelEndpoint
		}
	}
	return PathRoute{
		Destination: psb.Session.TunnelEndpoint,
		Source:      psb.SenderTemplate.SenderAddr,
		NextHop:     nextHop,
		Lookup:      psb.Route.Lookup,
		IfIndex:     psb.Route.IfIndex,
	}
}

func ownObjects(objects [][]byte) [][]byte {
	if len(objects) == 0 {
		return nil
	}
	size := 0
	for _, object := range objects {
		size += len(object)
	}
	storage := make([]byte, size)
	owned := make([][]byte, len(objects))
	for i, object := range objects {
		length := copy(storage, object)
		owned[i] = storage[:length:length]
		storage = storage[length:]
	}
	return owned
}

// sendResv re-sends this node's RESV upstream to keep the reservation soft-state
// alive (RFC 2205 Section 3.7). Egress and transit nodes hold an RSB and a valid
// PrevHop; an ingress LSP originates PATH instead, so it is skipped here.
func (e *engine) sendResv(lsp *LSP) error {
	lsp.mu.Lock()
	if lsp.RSB == nil || lsp.PSB == nil || !lsp.PrevHop.IsValid() {
		lsp.mu.Unlock()
		return nil
	}
	bypassKey := lsp.Bypass
	lsp.mu.Unlock()
	// The bypass has its own lock. Read it before reacquiring the protected
	// LSP lock, as in handleResvTransit.
	bypassUp := e.bypassEstablished(bypassKey)
	objects := e.reservationObjects(lsp)
	lsp.mu.Lock()
	if lsp.RSB == nil || lsp.PSB == nil || !lsp.PrevHop.IsValid() {
		lsp.mu.Unlock()
		return nil
	}
	if !lsp.PSB.RecordRoute {
		lsp.RSB.RRO = nil
	}
	if len(lsp.RSB.RRO) > 0 {
		self := &lsp.RSB.RRO[0]
		if self.Type == RROSubIPv4 && self.Address == e.cfg().RouterID {
			// RFC 4090 Section 6: "Until a PLR has a backup path available,
			// the PLR MUST clear the relevant four flags".
			self.Flags &^= RROFlagProtectionAvailable | RROFlagProtectionInUse |
				RROFlagBandwidthProtection | RROFlagNodeProtection
			if bypassUp && lsp.Bypass == bypassKey {
				self.Flags |= rroProtectionFlags(lsp)
			}
		}
	}
	type outgoingResv struct {
		dst netip.Addr
		raw []byte
	}
	var messages []outgoingResv
	if lsp.MergedPaths == nil {
		rsb := *lsp.RSB
		rsb.Hop, rsb.ForwardObjects = lsp.PSB.Hop, objects
		messages = append(messages, outgoingResv{lsp.PrevHop,
			buildResv(&rsb, lsp.PSB.SenderTemplate, e.cfg().RefreshPeriod, e.cfg().RouterID)})
	} else {
		confirmFilter := lsp.PSB.SenderTemplate
		if _, ok := lsp.MergedPaths[confirmFilter]; !ok {
			for filter := range lsp.MergedPaths {
				confirmFilter = filter
				break
			}
		}
		for filter, branch := range lsp.MergedPaths {
			rsb := *lsp.RSB
			rsb.Hop, rsb.ForwardObjects = branch.Hop, objects
			if filter != confirmFilter {
				rsb.ResvConfirm = netip.Addr{}
			}
			if !branch.RecordRoute {
				rsb.RRO = nil
			}
			messages = append(messages, outgoingResv{branch.PrevHop,
				buildResv(&rsb, filter, e.cfg().RefreshPeriod, e.cfg().RouterID)})
		}
	}
	lsp.RSB.ResvConfirm = netip.Addr{}
	lsp.mu.Unlock()
	for _, message := range messages {
		if len(message.raw) == 0 {
			return errReservationMessage
		}
	}

	var sendErr error
	for _, msg := range messages {
		if err := e.transport.Send(msg.dst, msg.raw); err != nil {
			sendErr = err
			continue
		}
		if m := rsvpteMetricsPtr.Load(); m != nil {
			m.resvMsgSent.Inc()
		}
	}
	return sendErr
}

const defaultIPTTL = 64

// handlePath processes a received PATH. This node is the egress (tail-end) when
// the SESSION tunnel endpoint is our router-id; otherwise it is a transit node
// and relays the PATH downstream along the ERO.
func (e *engine) handlePath(src netip.Addr, msg *ParsedMessage) {
	if m := rsvpteMetricsPtr.Load(); m != nil {
		m.pathMsgRecv.Inc()
	}
	if !msg.HasSession || !msg.HasSenderTemplate {
		e.log.Warn("rsvp-te: PATH missing SESSION/SENDER_TEMPLATE", "src", src)
		return
	}
	// RFC 2205 Section 2: "A Path message is required to carry a Sender Tspec,
	// which defines the traffic characteristics of the data flow that the
	// sender will generate." Section 3.1.3 writes it unbracketed beside the
	// template, "<sender descriptor> ::= <SENDER_TEMPLATE> <SENDER_TSPEC>", so
	// a PATH naming a sender and no traffic is malformed. Appendix B says what
	// a malformed message gets, and it is not a PathErr: "the error is simply
	// logged locally". Admitting it would reserve at a token rate of zero, a
	// value the sender never asked for.
	if !msg.HasSenderTSpec {
		e.log.Warn("rsvp-te: PATH missing SENDER_TSPEC", "src", src)
		return
	}
	// RFC 3209 Section 4.2.4: "If a LABEL_REQUEST object was not present in the
	// Path message, a node MUST NOT include a LABEL object in a Resv message for
	// that Path message's session and PHOP." Ze reserves for LSP tunnels only, so
	// a label-less reservation is one it cannot hold: no state is installed and
	// no RESV is sent for it, which keeps every LABEL Ze emits behind a request.
	if !msg.HasLabelRequest {
		e.log.Warn("rsvp-te: PATH without LABEL_REQUEST, no LSP to reserve", "src", src)
		return
	}
	if !e.cfg().Policy.allows(msg.SenderTemplate.SenderAddr, msg.Session.TunnelEndpoint) {
		e.sendPathErr(src, msg, ErrCodePolicyControlFailure, 0)
		return
	}
	selected, err := e.resolveReceivedPath(msg)
	if err != nil {
		e.log.Warn("rsvp-te: explicit route rejected", "error", err)
		e.sendPathErr(src, msg, ErrCodeRoutingProblem, selected.ErrorValue)
		return
	}
	if e.mergeBackupPath(src, msg, selected.ERO) {
		return
	}
	if !selected.Route.NextHop.IsValid() && e.isLocalAddress(msg.Session.TunnelEndpoint) {
		e.handlePathEgress(src, msg)
		return
	}
	e.handlePathTransit(src, msg, selected)
}

// receivedRefreshPeriod returns the refresh period that sets the lifetime of the
// state this PATH creates. RFC 2205 Section 3.7: "Each Path or Resv message carries
// a TIME_VALUES object containing the refresh time R used to generate refreshes. The
// recipient node uses this R to determine the lifetime L of the stored state created
// or refreshed by the message." So the lifetime follows the SENDER's period, never
// this node's configured one: the sender refreshes on its own schedule, and a local
// refresh-period commit that shortened the lifetime of state a neighbor keeps alive
// would delete a live reservation on the next cleanup tick.
//
// TIME_VALUES is mandatory in a PATH (RFC 2205 Section 3.1.3) and in a RESV
// (Section 3.1.4), and checkMandatoryObjects refuses a message that omits one, so
// every message reaching here carries the object. What is left is an advertised
// refresh period of zero, which no lifetime can be computed from: that falls back
// to the 30-second default RFC 2205 Section 3.7 suggests. The value is clamped to
// maxRefreshPeriod so a neighbor cannot advertise a period that keeps ze's state
// alive for years.
func receivedRefreshPeriod(msg *ParsedMessage) time.Duration {
	if !msg.HasTimeValues || msg.TimeValues.RefreshPeriod == 0 {
		return DefaultRefreshPeriod
	}
	period := time.Duration(msg.TimeValues.RefreshPeriod) * time.Millisecond
	if period > maxRefreshPeriod {
		return maxRefreshPeriod
	}
	return period
}

// handlePathEgress acts as the receiver for this configured IPv4 LSP profile.
// An increased request is admitted before replacing the accepted reservation.
func (e *engine) handlePathEgress(src netip.Addr, msg *ParsedMessage) {
	key := keyFromMessage(msg)
	lsp, existed := e.table.GetOrCreate(key)
	lsp.mu.Lock()
	oldPSB := lsp.PSB
	popAccepted := lsp.Role == RoleEgress && lsp.State == LSPStateUp
	psb := receivedPathState(msg, oldPSB)
	psb.Protection = protectionFromPath(msg)
	lsp.PrevHop, lsp.PSB = src, psb
	if lsp.MergedPaths != nil {
		recomputeMergedAdspecLocked(lsp)
	}
	oldRSB, oldBandwidth, oldIface := lsp.RSB, lsp.Bandwidth, lsp.AdmissionIface
	label := lsp.InLabel
	lsp.mu.Unlock()
	allocated := label == 0
	if allocated {
		label = e.table.AllocateLabel()
	}
	flow := msg.SenderTSpec
	if flow.Service == serviceGeneral || flow.Service == 0 {
		flow.Service = serviceControlledLoad
	}
	flow.MaxPacketSize = msg.PathMTU
	rsb := &resvStateBlock{Session: msg.Session, FlowSpec: flow, Label: labelObject{Label: label},
		Style: StyleSharedExplicit, Hop: msg.Hop, PathMTU: msg.PathMTU,
		ForwardObjects: ownObjects(msg.ForwardObjects), LastRefresh: time.Now()}
	if msg.HasRRO {
		var recorded uint32
		if psb.RecordLabels {
			recorded = label
		}
		rsb.RRO = e.recordRoute(nil, msg.Session.TunnelID, 0, recorded)
		rsb.RRODropped = rsb.RRO == nil
	}
	raw := buildResv(rsb, msg.SenderTemplate, e.cfg().RefreshPeriod, e.cfg().RouterID)
	iface, _ := e.admissionInterface(src)
	bandwidth := float64(flow.TokenRate) * 8
	installErr := errForwardingUnavailable
	if len(raw) > 0 {
		installErr = e.admission.reserve(iface, key, rsb.Style, bandwidth)
		if installErr == nil {
			if e.fib == nil {
				installErr = errForwardingUnavailable
			} else if !popAccepted || oldRSB == nil || oldRSB.Label.Label != label || oldRSB.PathMTU != rsb.PathMTU {
				installErr = e.fib.programPop(label, netip.Addr{}, rsb.PathMTU)
			}
			if installErr != nil {
				e.restoreReservation(iface, key, oldRSB, oldBandwidth)
			}
		}
	}
	if installErr != nil {
		if allocated {
			e.table.releaseLabel(label)
		}
		if !existed {
			e.table.Remove(key)
		}
		code, value := ErrCodeTrafficControlSystem, uint16(0)
		if errors.Is(installErr, errAdmissionDenied) {
			code, value = ErrCodeAdmissionControlFailure, ErrValueRequestedBandwidth
		}
		e.sendPathErr(src, msg, code, value)
		return
	}
	lsp.mu.Lock()
	lsp.Role = RoleEgress
	lsp.InLabel, lsp.Reserved, lsp.AdmissionIface, lsp.Bandwidth = label, true, iface, bandwidth
	lsp.RSB = rsb
	lsp.mu.Unlock()
	if oldIface != "" && oldIface != iface {
		e.admission.release(oldIface, key)
	}
	if err := e.transport.Send(src, raw); err != nil {
		e.log.Warn("rsvp-te: send RESV failed", "dest", src, "error", err)
		return
	}
	lsp.mu.Lock()
	lsp.setState(LSPStateUp)
	lsp.mu.Unlock()
	if m := rsvpteMetricsPtr.Load(); m != nil {
		m.resvMsgSent.Inc()
	}
	emitLSPUp(e.log, lsp, e.table.Len())
}

// handlePathTransit stores sender state; bandwidth is reserved only when the
// downstream receiver selects FF or SE in its RESV.
func (e *engine) handlePathTransit(src netip.Addr, msg *ParsedMessage, selected pathSelection) {
	// RFC 2205 Section 3.8: bound relay so a cyclic/malformed ERO cannot loop a
	// PATH forever. Drop (do not install state or reserve) when the hop budget
	// is exhausted.
	if msg.Header.TTL <= 1 {
		e.log.Warn("rsvp-te: transit PATH TTL exhausted, dropping", "src", src, "dest", msg.Session.TunnelEndpoint)
		return
	}
	nextHop, rem := selected.Route.NextHop, selected.ERO

	key := keyFromMessage(msg)
	lsp, _ := e.table.GetOrCreate(key)
	lsp.mu.Lock()
	alreadyReserved := lsp.Reserved
	lsp.mu.Unlock()

	// RFC 4090: if the head-end requested local protection, this transit node is a
	// candidate PLR. Reconstruct the request and arm a configured bypass whose
	// merge point is the protected NHOP (link) or NNHOP (node protection). Arming
	// just records the association; the data-plane switch happens on link-down.
	pr := protectionFromPath(msg)
	var bypass *lspKey
	if pr != nil {
		if bk, sel := e.selectBypass(rem, pr); sel {
			bypass = &bk
		}
	}

	lsp.mu.Lock()
	lsp.Role = RoleTransit
	lsp.PrevHop = src
	lsp.NextHop = nextHop
	if !lsp.ProtectionInUse {
		lsp.Bypass = bypass
	}
	// The received SESSION_ATTRIBUTE outlives this packet's buffer: copy it once
	// into the path state so every relay and refresh forwards it unmodified
	// (RFC 3209 Section 4.7.4).
	var sessionAttr []byte
	if lsp.PSB != nil && bytes.Equal(lsp.PSB.SessionAttr, msg.SessionAttrRaw) {
		sessionAttr = lsp.PSB.SessionAttr
	} else {
		sessionAttr = bytes.Clone(msg.SessionAttrRaw)
	}
	var rro []rroEntry
	if msg.HasRRO {
		var recordLabel uint32
		if msg.SessionAttr.Flags&SessAttrLabelRecording != 0 {
			recordLabel = lsp.InLabel
		}
		rro = e.recordRoute(msg.RRO, msg.Session.TunnelID, 0, recordLabel)
	}
	refreshResv := false
	if !msg.HasRRO && lsp.RSB != nil {
		// RFC 3209 Section 4.4.3: "Subsequent Resv messages SHALL NOT
		// contain an RRO" after a PATH withdraws route recording.
		refreshResv = len(lsp.RSB.RRO) > 0
		lsp.RSB.RRO = nil
		lsp.RSB.RRODropped = false
	}
	previous := lsp.PSB
	lsp.PSB = receivedPathState(msg, previous)
	lsp.PSB.ERO, lsp.PSB.RRO = rem, rro
	lsp.PSB.Protection, lsp.PSB.SessionAttr = pr, sessionAttr
	lsp.PSB.Route = selected.Route
	lsp.PSB.Adspec = bytes.Clone(msg.AdspecRaw)
	if len(lsp.PSB.Adspec) > 0 {
		if err := updateAdspec(lsp.PSB.Adspec, selected.Route.MTU); err != nil {
			lsp.mu.Unlock()
			e.log.Warn("rsvp-te: invalid path advertisement", "error", err)
			return
		}
	}
	if lsp.MergedPaths != nil {
		recomputeMergedAdspecLocked(lsp)
	}
	if lsp.State != LSPStateUp {
		lsp.setState(LSPStatePathReceived)
	}
	repaired := lsp.ProtectionInUse
	var raw []byte
	if !repaired {
		raw = buildPath(lsp.PSB, e.cfg().RouterID, msg.Header.TTL-1)
	}
	lsp.mu.Unlock()
	if !repaired && len(raw) == 0 {
		e.sendPathErr(src, msg, ErrCodeTrafficControlSystem, 0)
		return
	}
	if refreshResv {
		// RFC 2205 Section 2.1: when state to be forwarded changes, "these
		// refresh messages must be generated and forwarded immediately".
		if err := e.sendResv(lsp); err != nil {
			e.log.Warn("rsvp-te: route-record withdrawal refresh failed", "lsp", key.String(), "error", err)
		}
	}
	if repaired {
		if err := e.sendPath(lsp); err != nil {
			e.log.Warn("rsvp-te: repaired PATH relay failed", "lsp", key.String(), "error", err)
		}
		return
	}

	if bypass != nil && !alreadyReserved {
		e.log.Info("rsvp-te: PLR armed bypass for protected LSP", "lsp", key.String(), "bypass", bypass.String())
	}

	// Relay the PATH downstream with a decremented TTL. The ERO is forwarded
	// unchanged (rem still begins with the next hop) so the next node strips
	// itself in turn. The protection request is relayed so downstream transits
	// also become candidate PLRs.
	// TIME_VALUES states the period at which the state this PATH creates downstream
	// will actually be refreshed (RFC 2205 Section 3.7), and a transit node relays a
	// PATH only when one arrives: the downstream cadence is the sender's period, not
	// this node's. Writing the local period here would let a refresh-period commit on
	// a transit node shrink the downstream node's cleanup timeout below the rate the
	// relays actually arrive at, and the downstream would delete a live reservation.
	// This node's own period governs the RESVs it generates upstream, which it does
	// refresh on that cadence (buildResv reads e.cfg().RefreshPeriod).
	route := PathRoute{Destination: msg.Session.TunnelEndpoint, Source: msg.SenderTemplate.SenderAddr, NextHop: nextHop,
		Lookup: selected.Route.Lookup, IfIndex: selected.Route.IfIndex}
	if err := e.transport.SendPath(route, raw); err != nil {
		e.log.Warn("rsvp-te: transit PATH relay failed", "next-hop", nextHop, "error", err)
		return
	}
	if m := rsvpteMetricsPtr.Load(); m != nil {
		m.pathMsgSent.Inc()
	}
	if !alreadyReserved {
		e.log.Info("rsvp-te: transit PATH relayed", "lsp", key.String(), "next-hop", nextHop)
	}
}

// remainingERO is a pure view for repair association, not a routing decision.
func (e *engine) remainingERO(ero []eroHop) []eroHop {
	for len(ero) > 0 && e.isLocalPrefix(ero[0].Address) {
		ero = ero[1:]
	}
	return ero
}

// handleResv processes a received RESV and dispatches by this node's role for
// the LSP: ingress programs a push and comes up; transit allocates a local
// label, programs a swap and relays the RESV upstream.
func (e *engine) handleResv(src netip.Addr, msg *ParsedMessage) {
	if m := rsvpteMetricsPtr.Load(); m != nil {
		m.resvMsgRecv.Inc()
	}
	if msg.Style != StyleFixedFilter && msg.Style != StyleSharedExplicit {
		e.rejectReservation(src, msg, nil, ErrCodeUnknownStyle, 0, false)
		return
	}
	// RFC 2205 Section 3.1.8: \"Each flow descriptor in a FF-style Resv
	// message must be processed independently\".
	for i := range msg.FlowDescriptors {
		descriptor := &msg.FlowDescriptors[i]
		for j := range descriptor.Filters {
			e.acceptReservation(src, msg, descriptor, &descriptor.Filters[j])
		}
	}
}

// recordRoute prepends this node to the received RRO and warns if the address
// and optional label exceed maxRecordRouteHops. The whole route is then dropped.
// selfFlags sets the RFC 4090 protection flags on this node's RRO subobject (0 at
// the head-end and egress; a PLR reports available/in-use/node protection).
// recordLabel, when non-zero, records this node's label right after its address
// (RFC 3209 Section 4.4.3 label recording), so an upstream PLR can learn the merge
// point's label for node-protection backup forwarding.
func (e *engine) recordRoute(downstream []rroEntry, tunnelID uint16, selfFlags uint8, recordLabel uint32) []rroEntry {
	self := e.cfg().RouterID
	rro, dropped := prependRRO(self, downstream, recordLabel)
	if dropped {
		e.log.Warn("rsvp-te: recorded route too big for one message, RRO dropped; possible routing loop",
			"limit", maxRecordRouteHops, "tunnel", tunnelID)
		return nil
	}
	// The flags and the label describe THIS node, so both go only on the
	// subobject prependRRO pushed for it. With no valid self address nothing was
	// pushed and rro[0] is the downstream node's own entry: writing there would
	// report another node's protection state and, per RFC 3209 Section 4.4.3
	// ("A node MUST NOT push on a Label Record subobject without also pushing on
	// an IPv4 or IPv6 subobject"), record a label under the wrong address.
	if len(rro) == 0 || rro[0].Type != RROSubIPv4 || rro[0].Address != self {
		return rro
	}
	if selfFlags != 0 {
		rro[0].Flags = selfFlags
	}
	return rro
}

// labelForAddr finds the label an address recorded in an RRO (the RROSubLabel
// subobject immediately following its address subobject, RFC 3209 Section 4.4.3).
// Returns 0 / false when the address is absent or recorded no label.
func labelForAddr(rro []rroEntry, addr netip.Addr) (uint32, bool) {
	for i := range rro {
		if rro[i].Type == RROSubIPv4 && rro[i].Address == addr {
			if i+1 < len(rro) && rro[i+1].Type == RROSubLabel {
				return rro[i+1].Label, true
			}
			return 0, false
		}
	}
	return 0, false
}

func (e *engine) handlePathErr(src netip.Addr, msg *ParsedMessage) {
	if m := rsvpteMetricsPtr.Load(); m != nil {
		m.pathErrRecv.Inc()
	}
	if !msg.HasSession {
		return
	}
	if msg.HasSenderTemplate {
		if lsp, ok := e.repairedLSP(keyFromMessage(msg), src); ok {
			lsp.mu.Lock()
			var raw []byte
			prev := lsp.PrevHop
			ingress := lsp.Role == RoleIngress
			if lsp.PSB != nil {
				if ingress {
					msg.SenderTemplate = lsp.PSB.SenderTemplate
				}
				if !ingress {
					raw = buildPathErr(lsp.PSB.Session, lsp.PSB.SenderTemplate,
						lsp.PSB.SenderTSpec, msg.ErrorSpec, e.cfg().RouterID)
				}
			}
			lsp.mu.Unlock()
			if !ingress {
				if len(raw) > 0 {
					if err := e.transport.Send(prev, raw); err != nil {
						e.log.Warn("rsvp-te: backup PathErr relay failed", "lsp", lsp.Key.String(), "error", err)
					}
				}
				return
			}
		}
	}
	if lsp, ok := e.table.Get(keyFromMessage(msg)); ok {
		lsp.mu.Lock()
		if lsp.Role == RoleTransit && lsp.PSB != nil {
			type outgoingError struct {
				dst netip.Addr
				raw []byte
			}
			var messages []outgoingError
			if lsp.MergedPaths == nil {
				messages = append(messages, outgoingError{lsp.PrevHop,
					buildPathErr(lsp.PSB.Session, lsp.PSB.SenderTemplate, lsp.PSB.SenderTSpec, msg.ErrorSpec, e.cfg().RouterID)})
			} else {
				for filter, branch := range lsp.MergedPaths {
					messages = append(messages, outgoingError{branch.PrevHop,
						buildPathErr(lsp.PSB.Session, filter, lsp.PSB.SenderTSpec, msg.ErrorSpec, e.cfg().RouterID)})
				}
			}
			lsp.mu.Unlock()
			for _, outgoing := range messages {
				if err := e.transport.Send(outgoing.dst, outgoing.raw); err != nil {
					e.log.Warn("rsvp-te: PathErr relay failed", "lsp", lsp.Key.String(), "error", err)
				}
			}
			return
		}
		lsp.mu.Unlock()
	}
	eb := getEventBus()
	if eb != nil {
		evt := &pathErrEvent{
			TunnelEndpoint: msg.Session.TunnelEndpoint.String(),
			TunnelID:       msg.Session.TunnelID,
			ErrorCode:      msg.ErrorSpec.ErrorCode,
			ErrorValue:     msg.ErrorSpec.ErrorValue,
			ErrorNode:      msg.ErrorSpec.ErrorNode.String(),
		}
		if _, err := PathErr.Emit(eb, evt); err != nil {
			e.log.Warn("rsvp-te: path-err emit failed", "error", err)
		}
	}
	// RFC 4090 Section 6.5: a Notify ("Tunnel locally repaired") from a PLR means
	// this LSP is now riding its bypass. The head-end re-optimizes onto a fresh
	// path (make-before-break) and lets the old, locally-repaired LSP be torn down
	// once the replacement is up.
	if msg.HasSenderTemplate && msg.ErrorSpec.ErrorCode == ErrCodeNotify &&
		msg.ErrorSpec.ErrorValue == ErrValueTunnelLocallyRepaired {
		e.reoptimizeOnNotify(keyFromMessage(msg))
	}
	e.log.Info("rsvp-te: PathErr received", "tunnel", msg.Session.TunnelEndpoint,
		"code", msg.ErrorSpec.ErrorCode, "value", msg.ErrorSpec.ErrorValue)
}

func (e *engine) handlePathTear(msg *ParsedMessage) {
	if !msg.HasSession || !msg.HasSenderTemplate {
		return
	}
	key := keyFromMessage(msg)
	lsp, ok := e.table.Get(key)
	if !ok {
		lsp, ok = e.mergedLSP(key)
	}
	if !ok {
		return
	}
	lsp.mu.Lock()
	if lsp.MergedPaths != nil {
		branch, matched := lsp.MergedPaths[msg.SenderTemplate]
		if !matched || branch.Hop != msg.Hop {
			lsp.mu.Unlock()
			return
		}
		delete(lsp.MergedPaths, msg.SenderTemplate)
		if len(lsp.MergedPaths) > 0 {
			recomputeMergedAdspecLocked(lsp)
			lsp.mu.Unlock()
			return
		}
	}
	if lsp.MergedPaths == nil && (lsp.PSB == nil || lsp.PSB.Hop != msg.Hop) {
		// RFC 2205 Section 3.1.5: "Matching state must have match the
		// SESSION, SENDER_TEMPLATE, and PHOP objects."
		lsp.mu.Unlock()
		return
	}
	lsp.mu.Unlock()
	key = lsp.Key
	if e.table.Remove(key) == nil {
		return
	}
	// Snapshot fields under the LSP lock; a refresh/show goroutine may still
	// hold this pointer until it next consults the table.
	lsp.mu.Lock()
	role := lsp.Role
	inLabel := lsp.InLabel
	tearRoute, tearRaw := e.pathTearLocked(lsp)
	admIface := lsp.AdmissionIface
	isBypass := lsp.IsBypass
	lsp.mu.Unlock()
	if isBypass {
		e.clearBypassReferences(key)
	}

	if admIface != "" {
		e.admission.release(admIface, key)
	}
	if e.fib != nil {
		switch role {
		case RoleTransit:
			if inLabel != 0 {
				if err := e.fib.removeSwap(inLabel); err != nil {
					e.log.Warn("rsvp-te: fib remove swap failed", "lsp", key.String(), "error", err)
				}
			}
		case RoleIngress:
			fec := netip.PrefixFrom(key.TunnelEndpoint, key.TunnelEndpoint.BitLen())
			tableID := uint32(0)
			if isBypass {
				tableID = bypassTableID(key)
			}
			if err := e.fib.removePush(fec, tableID); err != nil {
				e.log.Warn("rsvp-te: fib remove failed", "lsp", key.String(), "error", err)
			}
		case RoleEgress:
			// Egress programmed a pop (in-label keyed); withdraw it.
			if inLabel != 0 {
				if err := e.fib.removeSwap(inLabel); err != nil {
					e.log.Warn("rsvp-te: fib remove pop failed", "lsp", key.String(), "error", err)
				}
			}
		}
	}
	// Relay the teardown downstream so the rest of the LSP is cleared.
	if role == RoleTransit && len(tearRaw) > 0 {
		if err := e.transport.SendPath(tearRoute, tearRaw); err != nil {
			e.log.Warn("rsvp-te: transit PathTear relay failed", "next-hop", tearRoute.NextHop, "error", err)
		}
	}
	e.table.releaseLabel(inLabel)
	emitLSPDown(e.log, lsp, e.table.Len())
	e.log.Info("rsvp-te: PathTear processed", "lsp", key.String())
}

// rejectUnknownObject answers a message that carried an object class ze does not
// implement and whose Class-Num high-order bit is zero. RFC 2205 Section 3.10
// rejects the whole message, and Appendix B returns Error Code 13 with the
// object's (Class-Num, C-Type) as the Error Value. Nothing in the message is
// acted on: handlePacket calls this instead of dispatching on the message type.
//
// RFC 4090 Section 4.2 is the case that matters today. A Path carrying a DETOUR
// object (Class-Num 63) reaches an LSR with no one-to-one backup support, and the
// PathErr is what tells the PLR its detour LSP is not established. Without it the
// PLR believes it has a working detour that nothing on this node will ever use.
func (e *engine) rejectUnknownObject(src netip.Addr, msg *ParsedMessage) {
	obj := msg.UnknownObject
	e.log.Warn("rsvp-te: message rejected, unknown object class",
		"src", src, "msg-type", msg.Header.MsgType, "class-num", obj.ClassNum, "c-type", obj.CType)
	code := ErrCodeUnknownObjectClass
	if msg.UnknownCType {
		code = ErrCodeUnknownCType
	}
	value := uint16(obj.ClassNum)<<8 | uint16(obj.CType)
	if msg.Header.MsgType == MsgTypeResv && msg.HasSession && msg.HasStyle {
		if len(msg.FlowDescriptors) == 0 {
			e.rejectReservation(src, msg, nil, code, value, false)
		}
		for i := range msg.FlowDescriptors {
			e.rejectReservation(src, msg, &msg.FlowDescriptors[i], code, value, false)
		}
		return
	}
	if msg.Header.MsgType == MsgTypePath && msg.HasSession && msg.HasSenderTemplate {
		e.sendPathErr(src, msg, code, value)
	}
}

func (e *engine) sendPathErr(dst netip.Addr, msg *ParsedMessage, code uint8, value uint16) {
	es := errorSpec{ErrorNode: e.cfg().RouterID, ErrorCode: code, ErrorValue: value}
	raw := buildPathErr(msg.Session, msg.SenderTemplate, msg.SenderTSpec, es, e.cfg().RouterID, msg.ForwardObjects...)
	if len(raw) == 0 {
		return
	}
	if err := e.transport.Send(dst, raw); err != nil {
		e.log.Warn("rsvp-te: send PathErr failed", "dest", dst, "error", err)
	}
}

// handleLinkDown reacts to interface ifaceName going down. Every LSP whose
// bandwidth was reserved against that interface has lost its downstream path, so
// RSVP-TE reports the failure toward the head-end -- a transit/egress node sends
// a PathErr upstream, an ingress head-end emits a local path-err event -- and
// tears the local state. RFC 2205 Section 3.1.3 (PathErr toward the sender);
// RFC 3209 Section 4.3.5 error code 24 "Routing Problem" value 5 "No route
// available toward destination".
//
// It runs from the interface-event subscription goroutine; the LSP table,
// per-LSP locks and admission controller are all concurrency-safe (the cleanup
// loop already mutates them off the engine goroutine).
func (e *engine) handleLinkDown(ifaceName string) {
	if ifaceName == "" {
		return
	}
	if err := e.refreshLocalAddresses(); err != nil {
		e.log.Warn("rsvp-te: local address lookup failed during link failure", "error", err)
	}
	es := errorSpec{ErrorNode: e.cfg().RouterID, ErrorCode: ErrCodeRoutingProblem, ErrorValue: ErrValueNoRouteAvailable}
	for _, lsp := range e.table.All() {
		lsp.mu.Lock()
		nextHop := lsp.NextHop
		state := lsp.State
		key := lsp.Key
		role := lsp.Role
		prevHop := lsp.PrevHop
		psb := lsp.PSB
		lsp.mu.Unlock()
		// An LSP is affected when the interface toward its DOWNSTREAM next hop is
		// the one that failed. Match on that link, not on AdmissionIface: the
		// reservation is charged against the upstream (PHOP) interface, and an
		// ingress LSP never sets AdmissionIface at all, so matching AdmissionIface
		// targets the wrong link (or no link) for the failure (F7).
		//
		// Egress LSPs have no NextHop (the tail disposes to IP, not to an LSP hop),
		// so they only match here via the single-interface admissionInterface
		// shortcut. Detecting an egress-side link failure precisely would need the
		// inner FEC's IP-FIB egress interface, which RSVP-TE does not track; the
		// upstream learns of an egress that stops refreshing via soft-state expiry.
		iface, ok := e.admissionInterface(nextHop)
		if state == LSPStateDown || !ok || iface != ifaceName {
			continue
		}

		// RFC 4090 Section 6.5: a protected transit LSP with a ready bypass is
		// locally repaired -- traffic is redirected onto the bypass and the
		// head-end is notified (PathErr Notify, code 25/3) -- instead of being torn
		// down. The protected LSP keeps forwarding via the bypass until the
		// head-end re-optimizes.
		if role != RoleEgress && e.tryLocalRepair(lsp, key) {
			if psb != nil && prevHop.IsValid() {
				nes := errorSpec{ErrorNode: e.cfg().RouterID, ErrorCode: ErrCodeNotify, ErrorValue: ErrValueTunnelLocallyRepaired}
				raw := buildPathErr(psb.Session, psb.SenderTemplate, psb.SenderTSpec, nes, e.cfg().RouterID)
				if err := e.transport.Send(prevHop, raw); err != nil {
					e.log.Warn("rsvp-te: local-repair Notify send failed", "lsp", key.String(), "iface", ifaceName, "error", err)
				}
			}
			if role == RoleIngress {
				e.reoptimizeOnNotify(key)
			}
			e.log.Info("rsvp-te: LSP locally repaired on link failure", "lsp", key.String(), "iface", ifaceName)
			continue
		}

		switch role {
		case RoleTransit, RoleEgress:
			if psb != nil && prevHop.IsValid() {
				raw := buildPathErr(psb.Session, psb.SenderTemplate, psb.SenderTSpec, es, e.cfg().RouterID)
				if err := e.transport.Send(prevHop, raw); err != nil {
					e.log.Warn("rsvp-te: link-down PathErr send failed", "lsp", key.String(), "iface", ifaceName, "error", err)
				}
			}
		case RoleIngress:
			e.emitLocalPathErr(key, es)
		}
		e.tearLSPLocal(key)
		e.log.Info("rsvp-te: LSP torn down on link failure", "lsp", key.String(), "iface", ifaceName)
	}
}

// emitLocalPathErr publishes a path-err event for an LSP whose failure was
// detected at the head-end itself, where there is no upstream node to receive a
// wire PathErr.
func (e *engine) emitLocalPathErr(key lspKey, es errorSpec) {
	eb := getEventBus()
	if eb == nil {
		return
	}
	evt := &pathErrEvent{
		TunnelEndpoint: key.TunnelEndpoint.String(),
		TunnelID:       key.TunnelID,
		ErrorCode:      es.ErrorCode,
		ErrorValue:     es.ErrorValue,
		ErrorNode:      es.ErrorNode.String(),
	}
	if _, err := PathErr.Emit(eb, evt); err != nil {
		e.log.Warn("rsvp-te: local path-err emit failed", "error", err)
	}
}

// tearLSPLocal removes an LSP and its forwarding/admission state without relaying
// a teardown (the local link to it failed, so there is nothing to relay over). It
// mirrors the cleanup half of handlePathTear.
func (e *engine) tearLSPLocal(key lspKey) {
	lsp := e.table.Remove(key)
	if lsp == nil {
		return
	}
	lsp.mu.Lock()
	role := lsp.Role
	inLabel := lsp.InLabel
	admIface := lsp.AdmissionIface
	isBypass := lsp.IsBypass
	lsp.mu.Unlock()
	if isBypass {
		e.clearBypassReferences(key)
	}

	if admIface != "" {
		e.admission.release(admIface, key)
	}
	if e.fib != nil {
		switch role {
		case RoleTransit, RoleEgress:
			if inLabel != 0 {
				if err := e.fib.removeSwap(inLabel); err != nil {
					e.log.Warn("rsvp-te: fib remove failed on link-down", "lsp", key.String(), "error", err)
				}
			}
		case RoleIngress:
			fec := netip.PrefixFrom(key.TunnelEndpoint, key.TunnelEndpoint.BitLen())
			tableID := uint32(0)
			if isBypass {
				tableID = bypassTableID(key)
			}
			if err := e.fib.removePush(fec, tableID); err != nil {
				e.log.Warn("rsvp-te: fib remove failed on link-down", "lsp", key.String(), "error", err)
			}
		}
	}
	e.table.releaseLabel(inLabel)
	emitLSPDown(e.log, lsp, e.table.Len())
}

// admissionInterface resolves the interface to account a reservation against,
// given the LSP's neighbor on this node's link. With a single configured
// interface it is unambiguous. With several, the neighbor is matched against
// each interface's configured local prefix (the `address` leaf): the interface
// whose prefix contains the neighbor owns the link the LSP traverses here. If no
// interface matches (no prefixes configured, or neighbor outside them) admission
// accounting is skipped for this LSP rather than charged to the wrong link.
func (e *engine) admissionInterface(neighbor netip.Addr) (string, bool) {
	if len(e.cfg().Interfaces) == 1 {
		return e.cfg().Interfaces[0].Name, true
	}
	if !neighbor.IsValid() {
		return "", false
	}
	for _, ic := range e.cfg().Interfaces {
		if ic.Prefix.IsValid() && ic.Prefix.Contains(neighbor) {
			return ic.Name, true
		}
	}
	return "", false
}
