// Design: docs/research/l2tpv2-ze-integration.md -- auth/pool drain goroutines
// Related: handler.go -- AuthHandler, PoolHandler, AuthResult types
// Related: subsystem.go -- spawns drain goroutines per pppDriver

package l2tp

import (
	"fmt"
	"log/slog"

	"github.com/ze-software/ze/internal/component/l2tp/ppp"
	"github.com/ze-software/ze/internal/component/l2tp/subscriber"
	subevents "github.com/ze-software/ze/internal/component/l2tp/subscriber/events"
	"github.com/ze-software/ze/pkg/ze"
)

// authDrainResponse carries the handler result plus session IDs so the
// test harness can inspect decisions without a real Driver.
type authDrainResponse struct {
	tunnelID  uint16
	sessionID uint16
	result    AuthResult
}

// poolDrainResponse carries the handler result plus session IDs so the
// test harness can inspect decisions without a real Driver.
type poolDrainResponse struct {
	tunnelID  uint16
	sessionID uint16
	result    ppp.IPResponseArgs
}

// drainAuth reads EventAuthRequests from the channel and calls the
// handler, sending results on out. Used by tests. Exits when ch closes.
func drainAuth(logger *slog.Logger, ch <-chan ppp.AuthEvent, handler AuthHandler, out chan<- authDrainResponse) {
	for ev := range ch {
		req, ok := ev.(ppp.EventAuthRequest)
		if !ok {
			continue
		}

		respond := func(accept bool, msg string, blob []byte) error {
			out <- authDrainResponse{
				tunnelID:  req.TunnelID,
				sessionID: req.SessionID,
				result:    AuthResult{Accept: accept, Message: msg, AuthResponseBlob: blob, Handled: true},
			}
			return nil
		}

		resp := callAuthHandler(logger, handler, req, respond)
		if resp.Handled {
			continue
		}
		out <- authDrainResponse{
			tunnelID:  req.TunnelID,
			sessionID: req.SessionID,
			result:    resp,
		}
	}
}

// startAuthDrain spawns the production auth drain goroutine that reads
// from d.AuthEventsOut(), calls the registered handler, and forwards
// the decision to d.AuthResponse(). Exits when the channel closes
// (Driver.Stop). The done channel is closed on exit.
//
// resolve is called PER REQUEST, not once here. The auth slot is
// late-binding on purpose: l2tp-auth-local claims it in init() and
// l2tp-auth-radius re-claims it at configure time, which is what makes the
// precedence "RADIUS when configured, local otherwise"
// (internal/component/l2tp/plugins/authradius/register.go). This drain used to
// capture the handler once at subsystem start and hold it forever, so that
// precedence could never take effect: the listener binds before the plugins
// configure, so the captured handler was always local's. In
// test/l2tp/radius-acct-wire.ci the daemon bound at .365, RADIUS configured at
// .366, and local answered the request at .390 -- one millisecond too late to
// matter. A registry written to be re-claimed needs a consumer that re-reads
// it.
func startAuthDrain(logger *slog.Logger, d *ppp.Driver, resolve func() AuthHandler, bus ze.EventBus) <-chan struct{} {
	done := make(chan struct{})
	go func() {
		defer close(done)
		for ev := range d.AuthEventsOut() {
			handler := resolve()
			req, ok := ev.(ppp.EventAuthRequest)
			if !ok {
				continue
			}
			respond := func(accept bool, msg string, blob []byte) error {
				return d.AuthResponse(req.TunnelID, req.SessionID, accept, msg, blob)
			}
			r := callAuthHandler(logger, handler, req, respond)
			subscriber.RecordAuthResult(subscriber.AccessL2TP, r.Accept)
			if bus != nil {
				if _, err := subevents.SessionAuthResult.Emit(bus, &subevents.SessionAuthResultPayload{
					SessionID:  l2tpSessionID(req.TunnelID, req.SessionID),
					AccessType: subscriber.AccessL2TP,
					Username:   req.Username,
					Accept:     r.Accept,
					Reason:     r.Message,
				}); err != nil {
					logger.Warn("l2tp: auth-result emit failed", "error", err)
				}
			}
			if r.Handled {
				continue
			}
			if err := d.AuthResponse(req.TunnelID, req.SessionID, r.Accept, r.Message, r.AuthResponseBlob); err != nil {
				logger.Warn("l2tp: auth drain response failed",
					"tunnel", req.TunnelID, "session", req.SessionID, "error", err)
			}
		}
	}()
	return done
}

func callAuthHandler(logger *slog.Logger, handler AuthHandler, req ppp.EventAuthRequest, respond AuthRespondFunc) (result AuthResult) {
	if handler == nil {
		return AuthResult{Accept: false, Message: "no auth handler configured"}
	}

	defer func() {
		if r := recover(); r != nil {
			logger.Error("auth handler panic", "tunnel", req.TunnelID, "session", req.SessionID, "panic", fmt.Sprint(r))
			result = AuthResult{Accept: false, Message: "internal error"}
		}
	}()

	return handler(req, respond)
}

// drainPool reads EventIPRequests from the channel and calls the
// handler, sending results on out. Used by tests. Exits when ch closes.
func drainPool(logger *slog.Logger, ch <-chan ppp.IPEvent, handler PoolHandler, out chan<- poolDrainResponse) {
	for ev := range ch {
		req, ok := ev.(ppp.EventIPRequest)
		if !ok {
			continue
		}

		resp := callPoolHandler(logger, handler, req)
		out <- poolDrainResponse{
			tunnelID:  req.TunnelID,
			sessionID: req.SessionID,
			result:    resp,
		}
	}
}

// startPoolDrain spawns the production pool drain goroutine that reads
// from d.IPEventsOut(), calls the registered handler, and forwards the
// decision to d.IPResponse(). Exits when the channel closes
// (Driver.Stop). The done channel is closed on exit.
func startPoolDrain(logger *slog.Logger, d *ppp.Driver, resolve func() PoolHandler) <-chan struct{} {
	done := make(chan struct{})
	go func() {
		defer close(done)
		for ev := range d.IPEventsOut() {
			// Per request, for the same reason startAuthDrain resolves per
			// request: l2tp-pool claims its slot at configure time, after the
			// listener has bound.
			handler := resolve()
			req, ok := ev.(ppp.EventIPRequest)
			if !ok {
				continue
			}
			r := callPoolHandler(logger, handler, req)
			if err := d.IPResponse(req.TunnelID, req.SessionID, r); err != nil {
				logger.Warn("l2tp: pool drain response failed",
					"tunnel", req.TunnelID, "session", req.SessionID, "error", err)
			}
		}
	}()
	return done
}

func callPoolHandler(logger *slog.Logger, handler PoolHandler, req ppp.EventIPRequest) (result ppp.IPResponseArgs) {
	if handler == nil {
		return ppp.IPResponseArgs{Accept: false, Reason: "no pool handler"}
	}

	defer func() {
		if r := recover(); r != nil {
			logger.Error("pool handler panic", "tunnel", req.TunnelID, "session", req.SessionID, "panic", fmt.Sprint(r))
			result = ppp.IPResponseArgs{Accept: false, Reason: "internal error"}
		}
	}()

	return handler(req)
}
