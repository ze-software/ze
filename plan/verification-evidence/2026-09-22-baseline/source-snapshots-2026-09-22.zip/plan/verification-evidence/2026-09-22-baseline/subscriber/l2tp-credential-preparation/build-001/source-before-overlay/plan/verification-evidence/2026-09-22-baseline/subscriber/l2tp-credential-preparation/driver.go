// Disposable evidence driver. Build only with the prepared Go overlay.
package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/ze-software/ze/internal/le/deployment"
)

type progress struct {
	mu sync.Mutex
	work string
}

func (p *progress) Write(b []byte) (int, error) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if strings.HasPrefix(string(b), "credential-scratch=") {
		p.work = strings.TrimSpace(strings.TrimPrefix(string(b), "credential-scratch="))
	}
	return os.Stderr.Write(b)
}

func digest(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil { return "", err }
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil { return "", err }
	return hex.EncodeToString(h.Sum(nil)), nil
}

// Runtime IPC nodes have no file content. Their type and mode are retained.
func retain(work, destination string) ([]map[string]any, error) {
	var special []map[string]any
	err := filepath.WalkDir(work, func(path string, d fs.DirEntry, err error) error {
		if err != nil { return err }
		rel, err := filepath.Rel(work, path)
		if err != nil { return err }
		target := filepath.Join(destination, rel)
		info, err := d.Info()
		if err != nil { return err }
		if d.IsDir() { return os.MkdirAll(target, 0o700) }
		if !info.Mode().IsRegular() {
			special = append(special, map[string]any{"path": rel, "mode": info.Mode().String()})
			return nil
		}
		in, err := os.Open(path)
		if err != nil { return err }
		defer in.Close()
		out, err := os.OpenFile(target, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
		if err != nil { return err }
		_, copyErr := io.Copy(out, in)
		closeErr := out.Close()
		if copyErr != nil { return copyErr }
		return closeErr
	})
	return special, err
}

func main() {
	if len(os.Args) != 4 {
		fmt.Fprintln(os.Stderr, "usage: driver CHECKOUT ZE OUTPUT-DIRECTORY")
		os.Exit(2)
	}
	tree, binary, output := os.Args[1], os.Args[2], os.Args[3]
	before, err := digest(binary)
	if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(2) }
	if err := os.Mkdir(output, 0o700); err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(2) }
	if err := os.Setenv(deployment.EvidenceBinaryKey, binary); err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(2) }
	p := new(progress)
	run := deployment.NewL2TPPPP(tree)
	run.Progress = p
	started := time.Now().UTC()
	report, runErr := run.Run()
	finished := time.Now().UTC()
	p.mu.Lock()
	work := p.work
	p.mu.Unlock()
	var special []map[string]any
	var captureErr error
	if !strings.HasPrefix(work, "/tmp/effective-l2tp-ppp-") {
		captureErr = fmt.Errorf("runner did not expose its owned scratch path")
	} else {
		special, captureErr = retain(work, filepath.Join(output, "scratch"))
	}
	after, hashErr := digest(binary)
	result := map[string]any{
		"argv": os.Args, "started": started, "finished": finished,
		"daemon_sha256_before": before, "daemon_sha256_after": after,
		"native_report": report, "native_error": errorText(runErr),
		"scratch_path": work, "retention_error": errorText(captureErr),
		"hash_error": errorText(hashErr), "special_files": special,
		"negative_oracle": "unavailable; native failure is never credential-refusal proof",
	}
	body, err := json.MarshalIndent(result, "", "  ")
	if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(2) }
	if err := os.WriteFile(filepath.Join(output, "result.json"), append(body, '\n'), 0o600); err != nil {
		fmt.Fprintln(os.Stderr, err); os.Exit(2)
	}
	fmt.Println(string(body))
	if runErr != nil || captureErr != nil || hashErr != nil || before != after { os.Exit(2) }
	if !report.Proven { os.Exit(1) }
}

func errorText(err error) string {
	if err == nil { return "" }
	return err.Error()
}
