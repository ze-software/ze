// Design: docs/research/l2tpv2-ze-integration.md -- l2tp-auth-local plugin lifecycle
// Related: l2tpauthlocal.go -- atomic logger, Name constant
// Related: auth.go -- localAuth handler

package l2tpauthlocal

import (
	"encoding/json"
	"fmt"
	"net"
	"os"

	"github.com/ze-software/ze/internal/component/l2tp"
	"github.com/ze-software/ze/internal/component/l2tp/plugins/authlocal/yang"
	"github.com/ze-software/ze/internal/component/plugin/cli"
	"github.com/ze-software/ze/internal/component/plugin/registry"
	"github.com/ze-software/ze/internal/core/slogutil"
	sdk "github.com/ze-software/ze/pkg/plugin/sdk"
)

var authInstance = newLocalAuth()

const configRootL2TP = "l2tp"

func init() {
	l2tp.RegisterAuthHandler(authInstance.handle)

	reg := registry.Registration{
		Name:                    Name,
		Description:             "Static local user list for L2TP PPP authentication",
		Features:                "yang",
		YANG:                    yang.ZeL2TPAuthLocalConfYANG,
		ConfigRoots:             []string{configRootL2TP},
		InProcessConfigVerifier: verifyLocalAuthConfig,
		RunEngine:               runPlugin,
		ConfigureEngineLogger: func(loggerName string) {
			setLogger(slogutil.Logger(loggerName))
		},
	}
	reg.CLIHandler = func(args []string) int {
		cfg := cli.BaseConfig(&reg)
		cfg.ConfigLogger = func(level string) {
			setLogger(slogutil.PluginLogger(reg.Name, level))
		}
		return cli.RunPlugin(cfg, args)
	}
	if err := registry.Register(reg); err != nil {
		fmt.Fprintf(os.Stderr, "%s: registration failed: %v\n", Name, err)
		os.Exit(1)
	}
}

func verifyLocalAuthConfig(sections []sdk.ConfigSection) error {
	for _, sec := range sections {
		if sec.Root != configRootL2TP {
			continue
		}
		if _, err := parseUsersFromJSON(sec.Data); err != nil {
			return err
		}
	}
	return nil
}

func runPlugin(conn net.Conn) int {
	logger().Debug(Name + " plugin starting (RPC)")

	p := sdk.NewWithConn(Name, conn)
	defer func() { _ = p.Close() }()

	var current, pending, previous map[string]userEntry
	var applied bool
	parseSections := func(sections []sdk.ConfigSection) (map[string]userEntry, error) {
		users := current
		for _, sec := range sections {
			if sec.Root != configRootL2TP {
				continue
			}
			var err error
			users, err = parseUsersFromJSON(sec.Data)
			if err != nil {
				return nil, err
			}
		}
		return users, nil
	}
	p.OnConfigVerify(func(sections []sdk.ConfigSection) error {
		pending, previous, applied = nil, nil, false
		users, err := parseSections(sections)
		if err != nil {
			return err
		}
		pending = users
		return nil
	})
	p.OnConfigure(func(sections []sdk.ConfigSection) error {
		users, err := parseSections(sections)
		if err != nil {
			return err
		}
		current = users
		authInstance.setUsers(current)
		logger().Info("l2tp-auth-local: loaded users", "count", len(current))
		return nil
	})

	p.OnConfigApply(func(_ []sdk.ConfigDiffSection) error {
		if pending != nil {
			previous, current = current, pending
			pending = nil
			applied = true
			authInstance.setUsers(current)
			logger().Info("l2tp-auth-local: loaded users", "count", len(current))
		}
		return nil
	})

	p.OnConfigRollback(func(_ string) error {
		pending = nil
		if applied {
			current, previous, applied = previous, nil, false
			authInstance.setUsers(current)
		}
		return nil
	})

	ctx, cancel := sdk.SignalContext()
	defer cancel()
	if err := p.Run(ctx, sdk.Registration{
		WantsConfig:  []string{configRootL2TP},
		VerifyBudget: 1,
		ApplyBudget:  1,
	}); err != nil {
		logger().Error(Name+" plugin failed", "error", err)
		return 1
	}
	return 0
}

// parseUsersFromJSON extracts the user list from the JSON config data.
// JSON shape: {"auth":{"local":{"user":[{"name":"x","password":"y"}]}}}.
func parseUsersFromJSON(data string) (map[string]userEntry, error) {
	if data == "" {
		return make(map[string]userEntry), nil
	}
	var tree map[string]any
	if err := json.Unmarshal([]byte(data), &tree); err != nil {
		return nil, fmt.Errorf("%s: invalid config JSON: %w", Name, err)
	}
	return parseUsersFromTree(tree)
}

func parseUsersFromTree(tree map[string]any) (map[string]userEntry, error) {
	users := make(map[string]userEntry)

	l2tpBlock, ok := tree[configRootL2TP].(map[string]any)
	if !ok {
		return users, nil
	}
	authBlock, ok := l2tpBlock["auth"].(map[string]any)
	if !ok {
		return users, nil
	}
	localBlock, ok := authBlock["local"].(map[string]any)
	if !ok {
		return users, nil
	}
	userList, ok := localBlock["user"]
	if !ok {
		return users, nil
	}

	entries, ok := userList.([]any)
	if !ok {
		single, ok2 := userList.(map[string]any)
		if !ok2 {
			return nil, fmt.Errorf("%s: invalid user list type %T", Name, userList)
		}
		// A keyed `user <name> { ... }` list lowers to a map keyed by the user
		// name: {"alice": {"password": ...}, "bob": {...}}. The name is the map
		// key, not a field. A single entry that carries an explicit "name" field
		// (e.g. an array element delivered bare) is handled as one entry below.
		if _, hasNameField := single["name"]; hasNameField {
			entries = []any{single}
		} else {
			for name, val := range single {
				m, ok := val.(map[string]any)
				if !ok {
					return nil, fmt.Errorf("%s: invalid user entry type %T for %q", Name, val, name)
				}
				pw, _ := m["password"].(string)
				users[name] = userEntry{Name: name, secret: pw}
			}
			return users, nil
		}
	}

	for _, entry := range entries {
		m, ok := entry.(map[string]any)
		if !ok {
			continue
		}
		name, _ := m["name"].(string)
		if name == "" {
			return nil, fmt.Errorf("%s: user entry missing name", Name)
		}
		pw, _ := m["password"].(string)
		users[name] = userEntry{Name: name, secret: pw}
	}
	return users, nil
}

// SetUsersForTest allows tests to inject a user table without config.
func SetUsersForTest(entries map[string]string) {
	users := make(map[string]userEntry, len(entries))
	for name, pw := range entries {
		users[name] = userEntry{Name: name, secret: pw}
	}
	authInstance.setUsers(users)
}

// ResetForTest clears the user table and is intended for use in test cleanup.
func ResetForTest() {
	authInstance.setUsers(make(map[string]userEntry))
}

// HandleForTest returns the auth handler function for direct testing.
func HandleForTest() func(req any) (bool, string) {
	return func(req any) (bool, string) {
		// Type assertion handled by caller
		return false, "use authInstance.handle directly"
	}
}

// OnConfigureForTest triggers config parsing from a tree for testing.
func OnConfigureForTest(tree map[string]any) error {
	users, err := parseUsersFromTree(tree)
	if err != nil {
		return err
	}
	authInstance.setUsers(users)
	return nil
}
