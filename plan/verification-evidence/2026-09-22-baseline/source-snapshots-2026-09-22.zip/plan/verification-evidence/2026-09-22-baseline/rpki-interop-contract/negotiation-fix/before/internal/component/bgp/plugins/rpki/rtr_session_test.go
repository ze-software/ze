package rpki

import (
	"context"
	"encoding/binary"
	"io"
	"net"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func newTestRTRSession(t *testing.T, address string, port uint16, pref uint8, source string, cache *ROACache, aspas *aSPACache, stop <-chan struct{}) *RTRSession {
	t.Helper()
	session := newRTRSession(address, port, pref, source, cache, aspas, stop)
	t.Cleanup(func() {
		session.close()
		if session.dataLease != nil {
			session.dataLease.stop()
		}
	})
	return session
}

// TestRTRSessionStartsAtV2 exercises the actual TCP queries, including a cache
// that requires a supported lower version rather than the router's first choice.
func TestRTRSessionStartsAtV2(t *testing.T) {
	// RFC requirement: DRAFT-IETF-SIDROPS-8210BIS-7-1 positive -- the first TCP query uses the highest implemented RTR version, 2.
	queries := make(chan [2]byte, 2)
	replies := make(chan error, 2)
	attempt := 0
	port, _ := serveRTR(t, func(conn net.Conn) {
		if err := conn.SetDeadline(time.Now().Add(5*time.Second)); err != nil {
			replies <- err
			return
		}
		query := make([]byte, pduResetQueryLen)
		if _, err := io.ReadFull(conn, query); err != nil {
			replies <- err
			return
		}
		if query[1] == pduSerialQuery {
			var serial [4]byte
			if _, err := io.ReadFull(conn, serial[:]); err != nil {
				replies <- err
				return
			}
		}
		queries <- [2]byte{query[0], query[1]}
		attempt++
		if attempt == 1 {
			report := make([]byte, 16)
			n := writeErrorReport(report, 1, errUnsupportedVersion, nil)
			_, err := conn.Write(report[:n])
			replies <- err
			return
		}
		response, end := cacheResponsePDU(), endOfDataPDU()
		response[0], end[0] = 1, 1
		_, err := conn.Write(append(response, end...))
		replies <- err
	})
	roas, aspas := newROACache(), newASPACache()
	roas.Add(makeVRP("10.0.0.0/24", 24, 64500))
	aspas.Set(64500, []uint32{100})
	s := newTestRTRSession(t, "127.0.0.1", port, 100, "", roas, aspas, make(chan struct{}))
	s.serial = 42
	require.NoError(t, s.syncOnce())
	require.NoError(t, <-replies)
	require.NoError(t, <-replies)
	assert.Equal(t, [2]byte{2, pduSerialQuery}, <-queries)
	assert.Equal(t, [2]byte{1, pduResetQuery}, <-queries)
	assert.Equal(t, HopNoAttestation, aspas.checkPair(100, 64500))
	assert.Equal(t, ValidationNotFound, roas.Validate("10.0.0.0/24", 64500))
}

// TestHandlePDUVersionDowngrade rejects an unsupported-version response with
// no common lower version, rather than tolerating it forever on the same stream.
func TestHandlePDUVersionDowngrade(t *testing.T) {
	// RFC requirement: RFC8210-12-1 positive -- a fatal Unsupported Protocol Version error with no common version closes the transport.
	closed := make(chan error, 1)
	port, _ := serveRTR(t, func(conn net.Conn) {
		if err := conn.SetDeadline(time.Now().Add(5*time.Second)); err != nil {
			closed <- err
			return
		}
		query := make([]byte, pduResetQueryLen)
		if _, err := io.ReadFull(conn, query); err != nil {
			closed <- err
			return
		}
		report := make([]byte, 16)
		n := writeErrorReport(report, query[0], errUnsupportedVersion, nil)
		if _, err := conn.Write(report[:n]); err != nil {
			closed <- err
			return
		}
		_, err := conn.Read(query)
		closed <- err
	})
	s := newTestRTRSession(t, "127.0.0.1", port, 100, "", newROACache(), newASPACache(), make(chan struct{}))
	require.Error(t, s.syncOnce())
	require.ErrorIs(t, <-closed, io.EOF)
}

// TestASPAProviderListErrorOnWire checks the fatal report actually leaves the
// router and the rejected announcement never becomes a usable authorization.
func TestASPAProviderListErrorOnWire(t *testing.T) {
	// RFC requirement: RFC8210-5.11-1 negative -- a malformed non-Error-Report PDU still receives its required Error Report.
	// RFC requirement: RFC8210-5.11-4 positive -- the actual transmitted report has zero text length when diagnostic text is omitted.
	reported := make(chan []byte, 1)
	serverErr := make(chan error, 1)
	bad := aspaPDU(64500)
	port, _ := serveRTR(t, func(conn net.Conn) {
		if err := conn.SetDeadline(time.Now().Add(5*time.Second)); err != nil {
			serverErr <- err
			return
		}
		query := make([]byte, pduResetQueryLen)
		if _, err := io.ReadFull(conn, query); err != nil {
			serverErr <- err
			return
		}
		if _, err := conn.Write(bad); err != nil {
			serverErr <- err
			return
		}
		report := make([]byte, 16+len(bad))
		_, err := io.ReadFull(conn, report)
		reported <- report
		serverErr <- err
	})
	cache := newASPACache()
	s := newTestRTRSession(t, "127.0.0.1", port, 100, "", newROACache(), cache, make(chan struct{}))
	require.ErrorIs(t, s.syncOnce(), errASPAProviderList)
	require.NoError(t, <-serverErr)
	report := <-reported
	assert.Equal(t, byte(2), report[0])
	assert.Equal(t, byte(pduErrorRpt), report[1])
	assert.Equal(t, uint16(9), binary.BigEndian.Uint16(report[2:4]))
	assert.Equal(t, bad, report[12:12+len(bad)])
	assert.Equal(t, uint32(0), binary.BigEndian.Uint32(report[12+len(bad):]))
	assert.Equal(t, HopNoAttestation, cache.checkPair(100, 64500))
}

func TestRTRErrorReportIsNotAnswered(t *testing.T) {
	// RFC requirement: RFC8210-5.11-1 positive -- an erroneous Error Report is not answered with another Error Report.
	client, cache := net.Pipe()
	finished := make(chan struct{})
	observed := make(chan error, 1)
	t.Cleanup(func() {
		_ = client.Close()
		_ = cache.Close()
		<-finished
	})
	go func() {
		defer close(finished)
		defer func() { _ = cache.Close() }()
		if err := cache.SetDeadline(time.Now().Add(5 * time.Second)); err != nil {
			observed <- err
			return
		}
		// An unknown-version Error Report exercises the otherwise applicable
		// Unsupported Protocol Version response, not a harmless error code.
		report := []byte{99, pduErrorRpt, 0, 0, 0, 0, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0}
		if _, err := cache.Write(report); err != nil {
			observed <- err
			return
		}
		var answer [1]byte
		_, err := io.ReadFull(cache, answer[:])
		observed <- err
	}()
	s := newTestRTRSession(t, "cache.invalid", 323, 100, "", newROACache(), newASPACache(), make(chan struct{}))
	require.ErrorIs(t, s.readLoop(client), errRtrUnsupportedProtocol)
	require.NoError(t, client.Close())
	require.ErrorIs(t, <-observed, io.EOF)
}

// TestRTRUnknownNegotiationVersion checks the receive-side negotiation rule
// over TCP, including the required Error Report and transport termination.
func TestRTRUnknownNegotiationVersion(t *testing.T) {
	// RFC requirement: DRAFT-IETF-SIDROPS-8210BIS-7-2 positive -- an unrecognized version 99 Cache Response produces Error Report 4 and transport termination.
	// RFC requirement: DRAFT-IETF-SIDROPS-8210BIS-7-2 negative -- a recognized version 2 Cache Response completes synchronization without an Unsupported Version report.
	// RFC requirement: RFC8210-7-7 positive -- an unknown received version produces Error Report 4 and closes the stream.
	// RFC requirement: RFC8210-7-7 negative -- a supported received version completes its data transfer without an unsupported-version error.
	for _, version := range []byte{2, 99} {
		name := "recognized"
		if version == 99 {
			name = "unrecognized"
		}
		t.Run(name, func(t *testing.T) {
			type reply struct {
				report []byte
				err error
			}
			observed := make(chan reply, 1)
			port, _ := serveRTR(t, func(conn net.Conn) {
				if err := conn.SetDeadline(time.Now().Add(5*time.Second)); err != nil {
					observed <- reply{err: err}
					return
				}
				query := make([]byte, pduResetQueryLen)
				if _, err := io.ReadFull(conn, query); err != nil {
					observed <- reply{err: err}
					return
				}
				response := cacheResponsePDU()
				response[0] = version
				payload := response
				if version == 2 {
					end := endOfDataPDU()
					end[0] = version
					payload = append(payload, end...)
				}
				if _, err := conn.Write(payload); err != nil {
					observed <- reply{err: err}
					return
				}
				var report []byte
				if version == 99 {
					report = make([]byte, 16+len(response))
					if _, err := io.ReadFull(conn, report); err != nil {
						observed <- reply{err: err}
						return
					}
				}
				_, err := conn.Read(query)
				observed <- reply{report: report, err: err}
			})
			s := newTestRTRSession(t, "127.0.0.1", port, 100, "", newROACache(), newASPACache(), make(chan struct{}))
			err := s.syncOnce()
			if version == 99 {
				require.ErrorIs(t, err, errRtrUnsupportedProtocol)
			} else {
				require.NoError(t, err)
			}
			got := <-observed
			require.ErrorIs(t, got.err, io.EOF)
			if version == 99 {
				require.Len(t, got.report, 24)
				assert.Equal(t, pduErrorRpt, got.report[1])
				assert.Equal(t, errUnsupportedVersion, binary.BigEndian.Uint16(got.report[2:4]))
				assert.Equal(t, version, got.report[12])
			}
		})
	}
}

// TestPollingCadenceAtLeastHourly verifies a fresh session re-queries its cache at least once an
// hour.
//
// VALIDATES: RFC 6810 Section 6.1 -- the router polls (Serial/Reset Query) no less frequently than
// once an hour. The Run loop re-connects and re-queries after waiting pollDelay: the refresh
// interval when the last sync completed, the retry interval when the last query failed (RFC 8210
// Section 6). Both defaults seed that cadence at or below the one-hour ceiling.
// PREVENTS: A default cadence that lets VRP data go stale for more than an hour.
func TestPollingCadenceAtLeastHourly(t *testing.T) {
	// RFC requirement: RFC6810-6.1-1 positive -- a fresh session's default intervals (the wait
	// between one query and the next in Run's loop, whichever branch it takes) are <= one hour, so
	// the router re-queries at least hourly without any cache-supplied interval.
	// RFC requirement: RFC8210-8.1-1 positive -- the same Run-loop wait is what makes the router send
	// a Serial Query or Reset Query periodically under v1; the seeded interval is finite and short, so
	// polling recurs rather than stopping after the first sync.
	stopCh := make(chan struct{})
	s := newTestRTRSession(t, "192.0.2.1", 3323, 100, "", newROACache(), newASPACache(), stopCh)

	assert.LessOrEqual(t, s.retryInterval, time.Hour, "default re-query cadence is at least hourly")
}

// TestCacheResetTriggersResetQuery verifies a Cache Reset PDU puts the session back into full-reset
// mode.
//
// VALIDATES: RFC 6810 Section 6.3 -- on Cache Reset (the cache cannot serve the requested
// incremental) the router issues a Reset Query. handlePDU clears the serial to 0, which is exactly
// the condition connectAndSync uses to send a Reset Query on the next connection.
// PREVENTS: A Cache Reset being ignored, leaving the router stuck sending Serial Queries the cache
// cannot answer.
func TestCacheResetTriggersResetQuery(t *testing.T) {
	newSession := func() *RTRSession {
		stopCh := make(chan struct{})
		return newTestRTRSession(t, "192.0.2.1", 3323, 100, "", newROACache(), newASPACache(), stopCh)
	}

	t.Run("cache reset clears serial for a reset query", func(t *testing.T) {
		// RFC requirement: RFC6810-6.3-1 positive -- a Cache Reset PDU ends the current sync and
		// clears the serial to 0, so the next connectAndSync sends a Reset Query.
		// RFC requirement: RFC8210-8.3-1 positive -- with no more-preferred cache to fall back to
		// (ze runs every configured cache in parallel), the Cache Reset drives this same session back
		// to serial 0, which is exactly the Reset Query that fetches an entire new load.
		s := newSession()
		s.serial = 42 // pretend a prior incremental sync

		done, err := s.handlePDU(rTRHeader{Type: pduCacheReset}, make([]byte, pduHeaderLen))

		require.ErrorIs(t, err, errRtrCacheResetReceivedWillDo, "cache reset signals a full re-sync")
		assert.True(t, done, "the current sync attempt ends")
		assert.Equal(t, uint32(0), s.serial, "serial cleared to 0 drives a Reset Query on reconnect")
	})

	t.Run("serial notify does not force a reset query", func(t *testing.T) {
		// RFC requirement: RFC6810-6.3-1 negative -- an ordinary Serial Notify does NOT clear the
		// serial, so the reset-query fallback is specific to Cache Reset, not to any received PDU.
		// RFC requirement: RFC8210-8.3-1 negative -- a PDU that is not a Cache Reset leaves the serial
		// intact, so the full reload is triggered only by the Cache Reset the RFC names and never by an
		// arbitrary cache-to-router PDU.
		s := newSession()
		s.serial = 42

		done, err := s.handlePDU(rTRHeader{Type: pduSerialNotify}, make([]byte, pduHeaderLen))

		require.NoError(t, err)
		assert.False(t, done)
		assert.Equal(t, uint32(42), s.serial, "serial preserved: no Reset Query forced")
	})
}

// TestNoDataAvailableKeepsResetQueryMode verifies that a No Data Available error leaves the session
// in the state that re-issues Reset Queries.
//
// VALIDATES: RFC 6810 Section 6.4 -- when the cache reports No Data Available and there is no other
// cache to fall back to, the router keeps issuing periodic Reset Queries. handlePDU treats code 2 as
// non-fatal (the session is not torn down as an error) and leaves the serial at 0, so each Run-loop
// reconnect re-sends a Reset Query.
// PREVENTS: A No Data Available report being treated as fatal (giving up) or silently advancing the
// serial (switching to Serial Queries the empty cache cannot satisfy).
func TestNoDataAvailableKeepsResetQueryMode(t *testing.T) {
	newSession := func() *RTRSession {
		stopCh := make(chan struct{})
		return newTestRTRSession(t, "192.0.2.1", 3323, 100, "", newROACache(), newASPACache(), stopCh)
	}

	t.Run("no data available is non-fatal and keeps serial at zero", func(t *testing.T) {
		// RFC requirement: RFC6810-6.4-1 positive -- an Error Report with code 2 (No Data Available)
		// is non-fatal: handlePDU returns no error and leaves serial at 0, so the periodic Run-loop
		// reconnect keeps issuing Reset Queries.
		// RFC requirement: RFC8210-8.4-1 positive -- when the cache cannot supply an update and there
		// is no other cache to switch to, this is the state that makes the router keep issuing periodic
		// Reset Queries: non-fatal handling plus serial 0.
		s := newSession()
		require.Equal(t, uint32(0), s.serial)

		hdr := rTRHeader{Type: pduErrorRpt, SessionID: errNoDataAvail, Length: pduHeaderLen}
		done, err := s.handlePDU(hdr, make([]byte, pduHeaderLen))

		require.NoError(t, err, "No Data Available must not be fatal")
		assert.False(t, done, "the session stays up to retry")
		assert.Equal(t, uint32(0), s.serial, "serial stays 0 so the next query is a Reset Query")
		assert.False(t, isFatalError(errNoDataAvail), "code 2 is classified non-fatal")
	})

	t.Run("a completed sync advances the serial out of reset mode", func(t *testing.T) {
		// RFC requirement: RFC6810-6.4-1 negative -- once a sync completes (End of Data), the serial
		// advances to a non-zero value, so the next query is an incremental Serial Query, not a
		// periodic Reset Query. Reset-query polling is specific to the no-data (serial==0) condition.
		// RFC requirement: RFC8210-8.4-1 negative -- a session that HAS been supplied an update leaves
		// periodic-Reset-Query mode, so the periodic reload is confined to the cannot-supply case and
		// does not discard a healthy incremental sync.
		s := newSession()

		buf := make([]byte, pduEndOfDataLen)
		buf[1] = pduEndOfData
		binary.BigEndian.PutUint32(buf[4:8], pduEndOfDataLen)
		binary.BigEndian.PutUint32(buf[8:12], 77) // serial number

		done, err := s.handlePDU(rTRHeader{Type: pduEndOfData, Length: pduEndOfDataLen}, buf)

		require.NoError(t, err)
		assert.True(t, done, "End of Data completes the sync")
		assert.Equal(t, uint32(77), s.serial, "serial advanced: session leaves reset-query mode")
	})
}

// TestSerialNotifyIgnoredDuringStartup verifies that a Serial Notify arriving in the startup window
// (before version negotiation has settled and before the Cache Response) changes nothing.
//
// VALIDATES: RFC 8210 Sections 5.2 and 7 -- the router MUST ignore Serial Notify PDUs received from
// the cache during the initial startup period. handlePDU's pduSerialNotify arm returns (false, nil)
// without touching serial, sessionID or state (rtr_session.go:359-361).
// PREVENTS: A pre-negotiation Serial Notify advancing the serial, adopting a Session ID, or aborting
// the startup exchange -- and equally, a blanket "drop everything during startup" that would swallow
// the Cache Response the exchange depends on.
func TestSerialNotifyIgnoredDuringStartup(t *testing.T) {
	newSession := func() *RTRSession {
		stopCh := make(chan struct{})
		return newTestRTRSession(t, "192.0.2.1", 3323, 100, "", newROACache(), newASPACache(), stopCh)
	}

	t.Run("serial notify in the startup window is ignored", func(t *testing.T) {
		// RFC requirement: RFC8210-5.2-1 positive -- a Serial Notify received before the Cache Response
		// (state still "idle", the initial startup period) is ignored: no error, sync not complete, and
		// neither the Session ID it carries nor the serial in its body is adopted.
		// RFC requirement: RFC8210-7-8 positive -- the same PDU received before version negotiation has
		// completed is handled by ignoring it, so it neither aborts nor perturbs negotiation.
		s := newSession()
		require.Equal(t, sessionIdle, s.state, "startup window: no Cache Response seen")

		buf := make([]byte, 12)
		buf[0] = rtrVersionMax
		buf[1] = pduSerialNotify
		binary.BigEndian.PutUint16(buf[2:4], 0xBEEF) // Session ID offered by the notify
		binary.BigEndian.PutUint32(buf[4:8], 12)
		binary.BigEndian.PutUint32(buf[8:12], 999) // serial offered by the notify

		done, err := s.handlePDU(rTRHeader{Version: rtrVersionMax, Type: pduSerialNotify, SessionID: 0xBEEF, Length: 12}, buf)

		require.NoError(t, err, "a startup Serial Notify must not error the session")
		assert.False(t, done, "it does not complete or abort the startup exchange")
		assert.Equal(t, uint32(0), s.serial, "the notified serial is not adopted")
		assert.Equal(t, uint16(0), s.sessionID, "the notified Session ID is not adopted")
		assert.Equal(t, sessionIdle, s.state, "the startup state is untouched")
		assert.Equal(t, rtrVersionMax, s.version, "negotiation is not perturbed")
	})

	t.Run("cache response in the same window is acted on", func(t *testing.T) {
		// RFC requirement: RFC8210-5.2-1 negative -- the ignore is specific to Serial Notify: a Cache
		// Response arriving in the same startup window IS processed (Session ID adopted, state moves to
		// establish). An implementation that dropped every startup PDU would pass the positive case and
		// fail here, so the pair pins "ignore Serial Notify" rather than "ignore everything".
		// RFC requirement: RFC8210-7-8 negative -- likewise, handling Serial Notify by ignoring it does
		// not extend to the PDU that carries the negotiated Session ID.
		s := newSession()

		done, err := s.handlePDU(rTRHeader{Version: rtrVersionMax, Type: pduCacheResp, SessionID: 0xBEEF, Length: pduHeaderLen}, make([]byte, pduHeaderLen))

		require.NoError(t, err)
		assert.False(t, done)
		assert.Equal(t, uint16(0xBEEF), s.sessionID, "Cache Response is not ignored")
		assert.Equal(t, sessionEstablish, s.state, "the exchange advances")
	})
}

// TestFirstPDUOnConnectionIsAQuery verifies the router opens every transport connection with a query.
//
// VALIDATES: RFC 8210 Sections 7, 8.1 -- a router MUST start each transport connection by issuing
// either a Reset Query or a Serial Query. connectAndSync writes one of the two before entering
// readLoop (rtr_session.go:165-176), which is also what starts version negotiation.
// PREVENTS: A connection opening silently (waiting for the cache to speak first), which would stall
// the session and never negotiate a version.
func TestFirstPDUOnConnectionIsAQuery(t *testing.T) {
	// firstPDU dials a throwaway listener with the given session and returns the first bytes written.
	firstPDU := func(t *testing.T, prepare func(*RTRSession), want int) []byte {
		t.Helper()
		var lc net.ListenConfig
		ln, err := lc.Listen(context.Background(), "tcp", "127.0.0.1:0")
		require.NoError(t, err)
		defer func() { _ = ln.Close() }()

		tcpAddr, ok := ln.Addr().(*net.TCPAddr)
		require.True(t, ok, "listener address is a TCP address")
		port := tcpAddr.Port
		stopCh := make(chan struct{})
		defer close(stopCh)

		s := newTestRTRSession(t, "127.0.0.1", uint16(port), 100, "", newROACache(), newASPACache(), stopCh) //nolint:gosec // listener port fits uint16
		prepare(s)

		done := make(chan error, 1)
		go func() { done <- s.connectAndSync() }()

		conn, err := ln.Accept()
		require.NoError(t, err)
		require.NoError(t, conn.SetReadDeadline(time.Now().Add(10*time.Second)))

		buf := make([]byte, want)
		_, err = io.ReadFull(conn, buf)
		require.NoError(t, err, "the router must speak first on a new connection")

		_ = conn.Close() // ends readLoop so connectAndSync returns
		select {
		case <-done:
		case <-time.After(10 * time.Second):
			t.Fatal("connectAndSync did not return after the cache closed the connection")
		}
		return buf
	}

	t.Run("fresh session opens with a reset query", func(t *testing.T) {
		// RFC requirement: RFC8210-7-1 positive -- the very first bytes a fresh session writes on a
		// newly established transport are a Reset Query PDU, carrying the version that starts
		// negotiation.
		// RFC requirement: RFC8210-8.1-2 positive -- when the transport is first established with no
		// prior serial, that opening PDU is the Reset Query the RFC requires.
		buf := firstPDU(t, func(*RTRSession) {}, pduResetQueryLen)

		assert.Equal(t, rtrVersionMax, buf[0], "opening query carries the router's protocol version")
		assert.Equal(t, pduResetQuery, buf[1], "a serial-less session opens with a Reset Query")
		assert.Equal(t, uint32(pduResetQueryLen), binary.BigEndian.Uint32(buf[4:8]))
	})

	t.Run("resuming session opens with a serial query", func(t *testing.T) {
		// RFC requirement: RFC8210-7-1 positive -- a session resuming from a known serial still opens
		// the connection with a query, this time the Serial Query carrying its Session ID and serial;
		// the "connection starts with a query" rule holds on both branches.
		// RFC requirement: RFC8210-8.1-2 positive -- the same holds for a re-established transport.
		buf := firstPDU(t, func(s *RTRSession) {
			s.serial = 42
			s.sessionID = 0x1234
		}, pduSerialQueryLen)

		assert.Equal(t, rtrVersionMax, buf[0])
		assert.Equal(t, pduSerialQuery, buf[1], "a resuming session opens with a Serial Query")
		assert.Equal(t, uint16(0x1234), binary.BigEndian.Uint16(buf[2:4]))
		assert.Equal(t, uint32(42), binary.BigEndian.Uint32(buf[8:12]))
	})
}
