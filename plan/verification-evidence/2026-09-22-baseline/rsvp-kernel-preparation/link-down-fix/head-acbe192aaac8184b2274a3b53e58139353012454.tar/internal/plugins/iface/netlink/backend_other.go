// Design: docs/features/interfaces.md -- Non-Linux interface backend stub
// Overview: ifacenetlink.go -- package hub

//go:build !linux

package ifacenetlink

import (
	"fmt"
	"net/netip"
	"runtime"

	"github.com/ze-software/ze/internal/component/iface"
	"github.com/ze-software/ze/internal/core/rtproto"
	"github.com/ze-software/ze/pkg/ze"
)

// stubBackend implements iface.Backend on non-Linux platforms.
// All operations return "not supported" errors.
type stubBackend struct{}

func newNetlinkBackend() (iface.Backend, error) {
	return &stubBackend{}, nil
}

func unsupported() error {
	return fmt.Errorf("interface management not supported on %s", runtime.GOOS)
}

func (s *stubBackend) CreateDummy(_ string) error        { return unsupported() }
func (s *stubBackend) CreateVeth(_, _ string) error      { return unsupported() }
func (s *stubBackend) CreateBridge(_ string) error       { return unsupported() }
func (s *stubBackend) CreateVLAN(_ iface.VLANSpec) error { return unsupported() }
func (s *stubBackend) UpdateVLANQoSMap(_ string, _, _ map[uint32]uint32) error {
	return unsupported()
}
func (s *stubBackend) CreateTunnel(_ iface.TunnelSpec) error                { return unsupported() }
func (s *stubBackend) CreateWireguardDevice(_ string) error                 { return unsupported() }
func (s *stubBackend) CreateMacvlanDevice(_ iface.MacvlanSpec) error        { return unsupported() }
func (s *stubBackend) ConfigureWireguardDevice(_ iface.WireguardSpec) error { return unsupported() }
func (s *stubBackend) GetWireguardDevice(_ string) (iface.WireguardSpec, error) {
	return iface.WireguardSpec{}, unsupported()
}
func (s *stubBackend) CreateXFRM(_ iface.XFRMSpec) error { return unsupported() }
func (s *stubBackend) GetXFRMInfo(_ string) (iface.XFRMInfo, error) {
	return iface.XFRMInfo{}, unsupported()
}
func (s *stubBackend) DeleteInterface(_ string) error                           { return unsupported() }
func (s *stubBackend) AddAddress(_, _ string) error                             { return unsupported() }
func (s *stubBackend) RemoveAddress(_, _ string) error                          { return unsupported() }
func (s *stubBackend) ReplaceAddressWithLifetime(_, _ string, _, _ int) error   { return unsupported() }
func (s *stubBackend) AddAddressP2P(_, _, _ string) error                       { return unsupported() }
func (s *stubBackend) AddRoute(_, _, _ string, _ int, _ rtproto.Proto) error    { return unsupported() }
func (s *stubBackend) RemoveRoute(_, _, _ string, _ int, _ rtproto.Proto) error { return unsupported() }
func (s *stubBackend) ListRoutes(_, _ string) ([]iface.RouteInfo, error)        { return nil, unsupported() }
func (s *stubBackend) SetAdminUp(_ string) error                                { return unsupported() }
func (s *stubBackend) SetAdminDown(_ string) error                              { return unsupported() }
func (s *stubBackend) SetMTU(_ string, _ int) error                             { return unsupported() }
func (s *stubBackend) SetMACAddress(_, _ string) error                          { return unsupported() }
func (s *stubBackend) GetMACAddress(_ string) (string, error)                   { return "", unsupported() }
func (s *stubBackend) GetStats(_ string) (*iface.InterfaceStats, error)         { return nil, unsupported() }
func (s *stubBackend) LinkSpeedDuplex(_ string) (int, string)                   { return 0, "" }
func (s *stubBackend) ListInterfaces() ([]iface.InterfaceInfo, error)           { return nil, unsupported() }
func (s *stubBackend) GetInterface(_ string) (*iface.InterfaceInfo, error)      { return nil, unsupported() }
func (s *stubBackend) ListNeighbors(_ int) ([]iface.NeighborInfo, error)        { return nil, unsupported() }
func (s *stubBackend) RouteLookup(_ netip.Addr) (map[string]any, error)         { return nil, unsupported() }
func (s *stubBackend) AddressIsLocal(_ netip.Addr) (bool, error)                { return false, unsupported() }
func (s *stubBackend) ListKernelRoutes(_ string, _ int) ([]iface.KernelRoute, error) {
	return nil, unsupported()
}
func (s *stubBackend) ResetCounters(_ string) error              { return unsupported() }
func (s *stubBackend) BridgeAddPort(_, _ string) error           { return unsupported() }
func (s *stubBackend) BridgeDelPort(_ string) error              { return unsupported() }
func (s *stubBackend) BridgeSetSTP(_ string, _ bool) error       { return unsupported() }
func (s *stubBackend) SetupMirror(_, _ string, _, _ bool) error  { return unsupported() }
func (s *stubBackend) RemoveMirror(_ string) error               { return unsupported() }
func (s *stubBackend) ListMirrors() ([]iface.MirrorState, error) { return nil, unsupported() }
func (s *stubBackend) SetupLCPPair(_, _ string) error            { return unsupported() }
func (s *stubBackend) RemoveLCPPair(_ string) error              { return unsupported() }
func (s *stubBackend) StartMonitor(_ ze.EventBus) error          { return unsupported() }
func (s *stubBackend) StopMonitor()                              {}
func (s *stubBackend) Close() error                              { return nil }
