// Design: docs/architecture/iface/netlink-monitor.md -- unit tests for netlink message parsing
//
//go:build linux

package cmd

import (
	"net"
	"testing"
	"time"

	"github.com/vishvananda/netlink"
	"golang.org/x/sys/unix"
)

func TestParseNetlinkRouteMsg(t *testing.T) {
	_, dst, _ := net.ParseCIDR("10.0.0.0/24")
	gw := net.ParseIP("192.168.1.1")

	u := netlink.RouteUpdate{ //nolint:modernize // netlink.Route has a Type field of its own that RouteUpdate.Type shadows; keep the two levels visible.
		Type: unix.RTM_NEWROUTE,
		Route: netlink.Route{
			Dst:       dst,
			Gw:        gw,
			LinkIndex: 0,
			Table:     254,
			Protocol:  2,
			Priority:  100,
		},
	}

	ev := routeUpdateToEvent(&u)

	if ev["type"] != "route" {
		t.Errorf("type = %v, want route", ev["type"])
	}
	if ev["action"] != "new" {
		t.Errorf("action = %v, want new", ev["action"])
	}
	if ev["prefix"] != "10.0.0.0/24" {
		t.Errorf("prefix = %v, want 10.0.0.0/24", ev["prefix"])
	}
	if ev["gateway"] != "192.168.1.1" {
		t.Errorf("gateway = %v, want 192.168.1.1", ev["gateway"])
	}
	if ev["table"] != 254 {
		t.Errorf("table = %v, want 254", ev["table"])
	}

	ts, ok := ev["timestamp"].(string)
	if !ok || ts == "" {
		t.Error("timestamp missing or empty")
	}
	if _, err := time.Parse(time.RFC3339, ts); err != nil {
		t.Errorf("timestamp not RFC3339: %v", err)
	}
}

func TestParseNetlinkRouteMsgDelete(t *testing.T) {
	_, dst, _ := net.ParseCIDR("10.0.0.0/24")

	u := netlink.RouteUpdate{ //nolint:modernize // netlink.Route has a Type field of its own that RouteUpdate.Type shadows; keep the two levels visible.
		Type: unix.RTM_DELROUTE,
		Route: netlink.Route{
			Dst: dst,
		},
	}

	ev := routeUpdateToEvent(&u)

	if ev["action"] != "del" {
		t.Errorf("action = %v, want del", ev["action"])
	}
}

func TestParseNetlinkRouteMsgDefault(t *testing.T) {
	u := netlink.RouteUpdate{
		Type:  unix.RTM_NEWROUTE,
		Route: netlink.Route{},
	}

	ev := routeUpdateToEvent(&u)

	if ev["prefix"] != "default" {
		t.Errorf("prefix = %v, want default", ev["prefix"])
	}
}

func TestParseNetlinkLinkMsg(t *testing.T) {
	u := netlink.LinkUpdate{
		Link: &netlink.Dummy{
			Name:         "eth0",
			Index:        2,
			MTU:          1500,
			Flags:        net.FlagUp,
			HardwareAddr: net.HardwareAddr{0x00, 0x11, 0x22, 0x33, 0x44, 0x55},
		},
	}
	u.Header.Type = unix.RTM_NEWLINK

	ev := linkUpdateToEvent(u)

	if ev["type"] != "link" {
		t.Errorf("type = %v, want link", ev["type"])
	}
	if ev["interface"] != "eth0" {
		t.Errorf("interface = %v, want eth0", ev["interface"])
	}
	if ev["state"] != "up" {
		t.Errorf("state = %v, want up", ev["state"])
	}
	if ev["mtu"] != 1500 {
		t.Errorf("mtu = %v, want 1500", ev["mtu"])
	}
	if ev["mac"] != "00:11:22:33:44:55" {
		t.Errorf("mac = %v, want 00:11:22:33:44:55", ev["mac"])
	}
}

func TestParseNetlinkLinkMsgDelete(t *testing.T) {
	u := netlink.LinkUpdate{
		Link: &netlink.Dummy{Name: "veth0", Index: 5},
	}
	u.Header.Type = unix.RTM_DELLINK

	ev := linkUpdateToEvent(u)

	if ev["action"] != "del" {
		t.Errorf("action = %v, want del", ev["action"])
	}
}

func TestParseNetlinkAddrMsg(t *testing.T) {
	_, ipNet, _ := net.ParseCIDR("192.168.1.10/24")

	u := netlink.AddrUpdate{
		LinkAddress: *ipNet,
		LinkIndex:   2,
		NewAddr:     true,
	}

	ev := addrUpdateToEvent(u)

	if ev["type"] != "address" {
		t.Errorf("type = %v, want address", ev["type"])
	}
	if ev["action"] != "new" {
		t.Errorf("action = %v, want new", ev["action"])
	}
	if ev["address"] != "192.168.1.0/24" {
		t.Errorf("address = %v, want 192.168.1.0/24", ev["address"])
	}
	if ev["interface-index"] != 2 {
		t.Errorf("interface-index = %v, want 2", ev["interface-index"])
	}
}

func TestParseNetlinkAddrMsgDelete(t *testing.T) {
	_, ipNet, _ := net.ParseCIDR("10.0.0.1/32")

	u := netlink.AddrUpdate{
		LinkAddress: *ipNet,
		LinkIndex:   3,
		NewAddr:     false,
	}

	ev := addrUpdateToEvent(u)

	if ev["action"] != "del" {
		t.Errorf("action = %v, want del", ev["action"])
	}
}

func TestNetlinkMonitorCancellation(t *testing.T) {
	// Verified by the handler's select on ctx.Done().
	// On non-Linux this test validates the stub returns an error.
	// On Linux the streaming handler blocks until context cancellation;
	// a full integration test is in test/plugin/monitor-system-netlink.ci.
}

// VALIDATES: a link message populates ifNameCache and RTM_DELLINK clears it,
// so the cache carries only entries a link message named.
// Producer: linkUpdateToEvent (monitor_netlink_linux.go).
func TestLinkMsgOwnsTheNameCache(t *testing.T) {
	const idx = 424242
	ifNameCache.Delete(idx)
	t.Cleanup(func() { ifNameCache.Delete(idx) })

	u := netlink.LinkUpdate{
		Link: &netlink.Dummy{Name: "zetest0", Index: idx},
	}
	u.Header.Type = unix.RTM_NEWLINK
	linkUpdateToEvent(u)

	if name, ok := ifNameCache.Load(idx); !ok || name != "zetest0" {
		t.Fatalf("after RTM_NEWLINK: cache holds %v (present=%v), want zetest0", name, ok)
	}

	u.Header.Type = unix.RTM_DELLINK
	linkUpdateToEvent(u)

	if name, ok := ifNameCache.Load(idx); ok {
		t.Fatalf("after RTM_DELLINK: cache still holds %v, want the entry gone", name)
	}
}

// VALIDATES: resolving an index does NOT write ifNameCache. A kernel interface
// index is reusable, so a route or address update still in flight for a deleted
// link must not cache the new link's name against that index and mislabel every
// later event. Producer: ifName (monitor_netlink_linux.go).
func TestIfNameLookupDoesNotRepopulateTheCache(t *testing.T) {
	lo, err := netlink.LinkByName("lo")
	if err != nil {
		t.Fatalf("LinkByName(lo): %v", err)
	}
	idx := lo.Attrs().Index

	// The link message for this index has been seen and then deleted, which is
	// the state a straggler route or address event arrives in.
	ifNameCache.Delete(idx)
	t.Cleanup(func() { ifNameCache.Delete(idx) })

	if got := ifName(idx); got != "lo" {
		t.Fatalf("ifName(%d) = %q, want lo", idx, got)
	}
	if name, ok := ifNameCache.Load(idx); ok {
		t.Fatalf("ifName cached %v; a reused index would then mislabel later events", name)
	}
}

// VALIDATES: the route path resolves its interface through ifName without
// leaving a cache entry behind.
// Producer: routeUpdateToEvent (monitor_netlink_linux.go).
func TestRouteEventDoesNotRepopulateTheCache(t *testing.T) {
	lo, err := netlink.LinkByName("lo")
	if err != nil {
		t.Fatalf("LinkByName(lo): %v", err)
	}
	idx := lo.Attrs().Index
	ifNameCache.Delete(idx)
	t.Cleanup(func() { ifNameCache.Delete(idx) })

	u := netlink.RouteUpdate{ //nolint:modernize // netlink.Route has a Type field of its own that RouteUpdate.Type shadows; keep the two levels visible.
		Type: unix.RTM_NEWROUTE,
		Route: netlink.Route{
			Dst:       &net.IPNet{IP: net.IPv4(10, 9, 8, 0), Mask: net.CIDRMask(24, 32)},
			LinkIndex: idx,
		},
	}

	ev := routeUpdateToEvent(&u)

	if ev["interface"] != "lo" {
		t.Fatalf("interface = %v, want lo", ev["interface"])
	}
	if name, ok := ifNameCache.Load(idx); ok {
		t.Fatalf("route event cached %v; the link path is the only writer", name)
	}
}
